import length.*;
import lengthTransformStrategy.UnitTransformStrategy;

public class LengthTransformer {

    public static LengthUnit unitTransform(LengthUnit lengthUnit, UnitTransformStrategy unitTransformStrategy) {
        return unitTransformStrategy.transform(lengthUnit);
    }

//    public static LengthUnit calculateLength(List<LengthUnit> lengthUnitList) {
//
//    }
}
