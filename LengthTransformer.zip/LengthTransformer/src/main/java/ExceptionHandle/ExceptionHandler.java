package ExceptionHandle;

public class ExceptionHandler {

    public static void ensureLengthNotIllegal(long length) {
        if (length < 0) {
            throw new IllegalArgumentException("enter illegal value");
        }
    }
}


