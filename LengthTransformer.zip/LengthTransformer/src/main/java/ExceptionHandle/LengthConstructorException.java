package ExceptionHandle;

public class LengthConstructorException extends Exception {
    public LengthConstructorException() {
        System.out.println("enter illegal value");
    }
}
