package lengthTransformStrategy;

import length.LengthUnit;

public interface UnitTransformStrategy {
    public LengthUnit transform(LengthUnit lengthUnit);
}
