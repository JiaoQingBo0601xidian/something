package lengthTransformStrategy;


import length.LengthUnit;

import java.util.List;

public interface CalculateStrategy {
    public double getLengthBase(List<LengthUnit> lengthUnitList);
}
