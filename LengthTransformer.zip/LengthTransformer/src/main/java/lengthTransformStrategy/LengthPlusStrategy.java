package lengthTransformStrategy;

import length.LengthUnit;

import java.math.BigDecimal;
import java.util.List;

public class LengthPlusStrategy implements CalculateStrategy {
    public double getLengthBase(List<LengthUnit> lengthUnitList) {
        double sumBase = 0.0;
        for (LengthUnit lengthUnit : lengthUnitList) {
            sumBase += BigDecimal.valueOf(lengthUnit.getCount() / (double) lengthUnit.getBase()).doubleValue();
        }
        return sumBase;
    }
}
