package lengthTransformStrategy;

import length.LengthUnit;
import length.Yard;

import static length.Yard.base;


public class Transform2Yard implements UnitTransformStrategy {
    public LengthUnit transform(LengthUnit lengthUnit) {
        return new Yard(lengthUnit.getCount() * base / lengthUnit.getBase());

    }
}
