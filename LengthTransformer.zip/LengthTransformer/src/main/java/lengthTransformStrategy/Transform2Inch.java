package lengthTransformStrategy;

import length.Inch;
import length.LengthUnit;

import static length.Inch.base;

public class Transform2Inch implements UnitTransformStrategy {
    public LengthUnit transform(LengthUnit lengthUnit) {
        return new Inch(lengthUnit.getCount() * base / lengthUnit.getBase());
    }

}
