package lengthTransformStrategy;

import length.LengthUnit;
import length.Mile;

import static length.Mile.*;

public class Transform2Mile implements UnitTransformStrategy {
    public LengthUnit transform(LengthUnit lengthUnit) {
        return new Mile(lengthUnit.getCount() * base / lengthUnit.getBase());

    }
}
