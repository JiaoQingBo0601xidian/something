package lengthTransformStrategy;

import length.Feet;
import length.LengthUnit;

import static length.Feet.base;


public class Transform2Feet implements UnitTransformStrategy {

    public LengthUnit transform(LengthUnit lengthUnit) {
        return new Feet(lengthUnit.getCount() * base / lengthUnit.getBase());
    }

}
