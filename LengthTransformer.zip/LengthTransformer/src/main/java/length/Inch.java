package length;

public class Inch extends LengthUnit {
    public final static int base = 63360;

    public Inch(long count) {
        super(count);
    }

    @Override
    public int getBase() {
        return this.base;
    }

}
