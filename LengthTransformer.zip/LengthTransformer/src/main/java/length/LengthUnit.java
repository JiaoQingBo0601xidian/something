package length;

import ExceptionHandle.ExceptionHandler;

import java.math.BigDecimal;

public abstract class LengthUnit {
    private long count;

    public LengthUnit(long count) {
        setCount(count);
    }

    public LengthUnit setCount(long count) {
        ExceptionHandler.ensureLengthNotIllegal(count);
        this.count = count;
        return this;
    }

    public long getCount() {
        return count;
    }

    public boolean lengthUnitCompare(LengthUnit lengthUnit) {
        BigDecimal big = new BigDecimal(this.getCount() * lengthUnit.getBase());
        BigDecimal small = new BigDecimal(lengthUnit.getCount() * this.getBase());
        if (big.doubleValue() / small.doubleValue() == 1) {
            return true;
        }
        return false;
    }

    public abstract int getBase();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LengthUnit that = (LengthUnit) o;

        if (count != that.count) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (count ^ (count >>> 32));
    }

}
