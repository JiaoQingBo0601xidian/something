package length;

public class Yard extends LengthUnit {

    public final static int base = 1760;

    public Yard(long count) {
        super(count);
    }

    @Override
    public int getBase() {
        return this.base;
    }

}
