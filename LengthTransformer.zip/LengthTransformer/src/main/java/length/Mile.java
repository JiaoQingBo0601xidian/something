package length;

public class Mile extends LengthUnit {
    public final static int base = 1;

    @Override
    public int getBase() {
        return this.base;
    }

    public Mile(long count) {
        super(count);
    }

}
