package length;

public enum TransformRates {
    MILE_BASE(1), YARD_BASE(1760), FEET_BASE(5280), INCH_BASE(63360);
    private int rateParam;

    TransformRates(int rateParam) {
        this.rateParam = rateParam;
    }

    public int getRateParam() {
        return rateParam;
    }
}
