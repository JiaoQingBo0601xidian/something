package length;

public class Feet extends LengthUnit {

    public final static int base = 5280;

    public Feet(long count) {
        super(count);
    }

    @Override
    public int getBase() {
        return this.base;
    }

}
