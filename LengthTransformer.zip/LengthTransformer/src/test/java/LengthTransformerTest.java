import length.*;
import lengthTransformStrategy.Transform2Inch;
import lengthTransformStrategy.Transform2Mile;
import lengthTransformStrategy.Transform2Yard;
import lengthTransformStrategy.Transform2Feet;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class LengthTransformerTest {

    Transform2Yard transform2Yard;
    Transform2Feet transform2Feet;
    Transform2Inch transform2Inch;
    Transform2Mile transform2Mile;

    Mile mile;
    Yard yard;
    Feet feet;
    Inch inch;

    @Before
    public void setUp() throws Exception {
        transform2Yard = new Transform2Yard();
        transform2Feet = new Transform2Feet();
        transform2Mile = new Transform2Mile();
        transform2Inch = new Transform2Inch();
        mile = new Mile(1);
        yard = new Yard(1);
        feet = new Feet(1);
        inch = new Inch(1);
    }


    @Test(expected = IllegalArgumentException.class)
    public void ��ʼ����һMileʱ�׳��쳣() {
        new Mile(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ��ʼ����һYardʱ�׳��쳣() {
        new Yard(-1);
    }

    @Test
    public void һMile��1760Yard���() {
        LengthUnit o = LengthTransformer.unitTransform(new Yard(1760), transform2Mile);
        assertTrue(mile.equals(o));
    }


    @Test
    public void һ760Yard��1Mile���() {
        LengthUnit yard = LengthTransformer.unitTransform(mile, transform2Yard);
        assertTrue(new Yard(1760).equals(yard));
    }

    @Test
    public void һ761Yard������1Mile() {
        assertFalse(new Yard(1761).lengthUnitCompare(mile));
    }

    @Test
    public void һ759Yard������1Mile() {
        assertFalse(new Yard(1759).lengthUnitCompare(mile));
    }

    @Test
    public void һMie������1759Yard() {
        assertFalse(mile.lengthUnitCompare(new Yard(1759)));
    }

    @Test
    public void һMie������1761Yard() {
        assertFalse(new Mile(1).lengthUnitCompare(new Yard(1761)));
    }

    @Test
    public void ��Feet����1Yard() throws Exception {
        assertTrue(new Feet(3).equals(LengthTransformer.unitTransform(yard, transform2Feet)));
    }

    @Test
    public void һYard������4Feet() throws Exception {
        assertFalse(new Feet(4).equals(LengthTransformer.unitTransform(yard, transform2Feet)));
    }

    @Test
    public void һYard������2Feet() throws Exception {
        assertFalse(new Feet(2).equals(LengthTransformer.unitTransform(yard, transform2Feet)));
    }

    @Test
    public void һMile����5280Feet() throws Exception {
        assertTrue(mile.equals(LengthTransformer.unitTransform(new Feet(5280), transform2Mile)));
    }

    @Test(expected = IllegalArgumentException.class)
    public void ��ʼ����һFeetʱ�׳��쳣() {
        new Feet(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ��ʼ����һInchʱ�׳��쳣() {
        new Inch(-1);
    }

    @Test
    public void һMile����63360Inch() throws Exception {
        assertTrue(new Inch(63360).equals(LengthTransformer.unitTransform(mile, transform2Inch)));
    }

    @Test
    public void һYard����36Inch() throws Exception {
        assertTrue(new Inch(36).equals(LengthTransformer.unitTransform(yard, transform2Inch)));
    }

    @Test
    public void һFeet����12Inch() throws Exception {
        assertTrue(new Inch(12).equals(LengthTransformer.unitTransform(feet, transform2Inch)));
    }

}
