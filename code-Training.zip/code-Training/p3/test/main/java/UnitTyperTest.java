

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

//@RunWith(Parameterized.class)
public class UnitTyperTest {
    private CmdRequest cmdRequest;
    private CmdResponse cmdResponse;

    private int in_ucInqType;
    private int out_wUnitType;
    private long expectResultCode;
    private boolean isCalled;

//    public UnitTyperTest() {
//    }

//    public UnitTyperTest(int in_ucInqType, int out_wUnitType, long expectResultCode, boolean isCalled) {
//        this.in_ucInqType = in_ucInqType;
//        this.out_wUnitType = out_wUnitType;
//        this.expectResultCode = expectResultCode;
//        this.isCalled = isCalled;
//    }

    @Before
    public void setUp() throws Exception {
        cmdRequest=new RequestForTest();
        cmdResponse=new ResponseForTest();
    }

    //======================


//    @Test
//    public void testCheckUnitType() throws Exception {
//        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,in_ucInqType,out_wUnitType);
//        assertEquals(expectResultCode,((ResponseForTest)cmdResponse).getCode());
//        assertEquals(isCalled,((ResponseForTest)cmdResponse).isCalled());
//        assertFalse(result);
//
//    }

    @Parameterized.Parameters
    public Collection dataFeed(){
        return Arrays.asList(new Object[][]{
                {0, 2,0,false},
                {0, 0,0,true},
                {0, 1,0,true}
        });
    }


    //=======================
    @Test
    public void 输入类型为0输出单位不为0和1返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,0,2);
        assertEquals(0,((ResponseForTest)cmdResponse).getCode());
        assertTrue(((ResponseForTest)cmdResponse).isCalled());
        assertFalse(result);
    }

    @Test
    public void 输入类型为0输出单位为0返回True() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,0,0);
        assertTrue(result);
    }

    @Test
    public void 输入类型为0输出单位为1返回True() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,0,1);
        assertTrue(result);
    }

    //=============

    @Test
    public void 输入类型为1输出单位不为0和1和2返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,1,3);
        assertFalse(result);
    }

    @Test
    public void 输入类型为1输出单位为0返回true() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,1,0);
        assertTrue(result);
    }

    @Test
    public void 输入类型为1输出单位为1返回true() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,1,1);
        assertTrue(result);
    }

    @Test
    public void 输入类型为1输出单位为2返回true() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,1,2);
        assertTrue(result);
    }

//=============

    @Test
    public void 输入类型为2输出单位为不为0和4返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,2,2);
        assertFalse(result);
    }

    @Test
    public void 输入类型为5输出单位为不为0和4返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,5,2);
        assertFalse(result);
    }

    //===================
    @Test
    public void 输入类型为3输出单位为不为2返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,3,3);
        assertFalse(result);
    }

    @Test
    public void 输入类型为3输出单位为2返回true() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,3,2);
        assertTrue(result);
    }

//======================

    @Test
    public void 输入类型为4输出单位为不为3返回false() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,4,4);
        assertFalse(result);
    }

    @Test
    public void 输入类型为4输出单位为为3返回true() throws Exception {
        boolean result=UnitTyper.checkUnitType(cmdRequest,cmdResponse,4,3);
        assertTrue(result);
    }
}