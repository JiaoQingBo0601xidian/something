import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import java.util.Arrays;
import java.util.Collection;
import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class UnitTyperTest2 {
    private CmdRequest cmdRequest;
    private CmdResponse cmdResponse;

    private int in_ucInqType;
    private int out_wUnitType;
    private long expectResultCode;
    private boolean isCalled;
    private boolean expectedResult;

    public UnitTyperTest2(int in_ucInqType, int out_wUnitType, long expectResultCode, boolean isCalled, boolean expectedResult) {
        this.in_ucInqType = in_ucInqType;
        this.out_wUnitType = out_wUnitType;
        this.expectResultCode = expectResultCode;
        this.isCalled = isCalled;
        this.expectedResult = expectedResult;
    }

    @Before
    public void setUp() throws Exception {
        cmdRequest = new RequestForTest();
        cmdResponse = new ResponseForTest();
    }
    //======================
    @Test
    public void testCheckUnitType() throws Exception {
        boolean result = UnitTyper.checkUnitType(cmdRequest, cmdResponse, in_ucInqType, out_wUnitType);
        assertEquals(expectResultCode, ((ResponseForTest) cmdResponse).getCode());
        assertEquals(isCalled, ((ResponseForTest) cmdResponse).isCalled());
        assertEquals(expectedResult, result);
    }

    @Parameters
    public static Collection dataFeed() {
        return Arrays.asList(new Object[][]{
                {0, 2, 0, true, false},
                {0, 0, -1, false, true},
                {0, 1, -1, false, true},
                //-=============
                {1, 3, 1, true, false},
                {1, 0, -1, false, true},
                {1, 1, -1, false, true},
                {1, 2, -1, false, true},
                //-=============
                {2, 2, 2, true, false},
                {5, 5, 2, true, false},
                //-=============
                {3, 3, 3, true, false},
                {3, 2, -1, false, true},
                //-=============
                {4, 4, 4, true, false},
                {4, 3, -1, false, true},
        });
    }


}