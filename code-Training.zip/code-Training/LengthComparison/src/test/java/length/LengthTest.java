package length;

import org.junit.Assert;
import org.junit.Test;

import static length.LengthCenter.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

public class LengthTest
{
    /*
       1Mile = 1760Yard

       �����������һ���µĵ�λ��Feet
       1Yard = 3Feet
       1Mile = 5280Feet

       ���������ټ���һ���µĵ�λ��Inch
       1Feet = 12Inch
       1Yard = 36Inch
       1Mile  = 63360Inch*/

    @Test
    public void should_return_equals_when_input_1Mile_and_1760Yard()
    {
        assertEquals(new Unit(1, MILE), new Unit(1760, YARD));
    }

    @Test
    public void should_false_when_input_1Mile_and_1761Yard()
    {
        assertFalse(new Unit(1, MILE).equals(new Unit(1761, YARD)));
    }

    @Test
    public void should_return_equals_when_input_1Yard_and_3Feet()
    {
        assertEquals(new Unit(1, YARD), new Unit(3, FEET));

    }

    @Test
    public void should_not_equal_when_input_1Feet_and_13Inch()
    {
        assertFalse(new Unit(1, FEET).equals(new Unit(13, INCH)));

    }

    @Test
    public void should_return_equals_when_input_1Yard_and_36Inch()
    {
        assertEquals(new Unit(1, YARD), new Unit(36, INCH));

    }

    @Test
    public void should_return_equals_when_input_1Mile_and_63360Inch()
    {
        assertEquals(new Unit(1, MILE), new Unit(63360, INCH));
    }

    @Test
    public void should_equals_between_36Inch_and_12Inch_plus_2Feet() throws Exception {
        Assert.assertEquals(new Unit(36, LengthCenter.INCH), new Unit(12, LengthCenter.INCH).add(new Unit(2, LengthCenter.FEET)));
    }

    @Test
    public void should_not_equals_between_36Inch_and_12Inch_plus_3Feet() throws Exception {
        Assert.assertNotEquals(new Unit(36, LengthCenter.INCH), new Unit(12, LengthCenter.INCH).add(new Unit(3, LengthCenter.FEET)));
    }

    @Test
    public void should_print_2Inch_when_input_2_Inch() {
        String expected = "2INCH";
        assertEquals(expected, new Unit(2, LengthCenter.INCH).printUnit());
    }

    @Test
    public void should_print_24INCH_when_input_2FEET() {
        String expected = "24INCH";
        assertEquals(expected, new Unit(2, LengthCenter.FEET).printUnit());
    }

    @Test
    public void should_print_108INCH_when_input_3YARD() {
        String expected = "108INCH";
        assertEquals(expected, new Unit(3, LengthCenter.YARD).printUnit());
    }

    @Test
    public void should_print_126720INCH_when_input_2MILE() {
        String expected = "126720INCH";
        assertEquals(expected, new Unit(2, LengthCenter.MILE).printUnit());
    }

    @Test
    public void should_not_print_2TSP_when_input_2INCH() {
        String expected = "2TSP";
        assertNotEquals(expected, new Unit(2, LengthCenter.INCH).printUnit());
    }
    @Test
    public void should_not_print_2TSP_when_input_MILE() {
        String expected = "2TSP";
        assertNotEquals(expected,new Unit(2123456789, LengthCenter.MILE).printUnit());
    }

    @Test
    public void should_print_2FEET_AND_11INCH_when_input_35INCH() {
        String expected = "2FEET 11INCH";
        assertEquals(expected, new Unit(35, LengthCenter.INCH).printWithMaxUnit());
    }

    @Test
    public void should_print_1YARD_AND_2INCH_when_input_38INCH() {
        String expected = "1YARD 2INCH";
        assertEquals(expected, new Unit(38, LengthCenter.INCH).printWithMaxUnit());
    }
    @Test
    public void should_print_1YARD_AND_1FEET_when_input_48INCH() {
        String expected = "1YARD 1FEET";
        assertEquals(expected, new Unit(48, LengthCenter.INCH).printWithMaxUnit());
    }
    @Test
    public void should_print_1YARD_AND_2FEET_when_input_5FEET() {
        String expected = "1YARD 2FEET";
        assertEquals(expected, new Unit(5, LengthCenter.FEET).printWithMaxUnit());
    }
}
