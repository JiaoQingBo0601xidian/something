package length;

/**
 * Created by 00189971 on 2016/4/22.
 */
public enum LengthCenter implements UnitCenter
{
    MILE(1760 * 3 * 12), YARD(1 * 3 * 12), FEET(1 * 12), INCH(1);

    private final int scale;

    LengthCenter(int scale)
    {
        this.scale = scale;
    }

    public int getScale()
    {
        return scale;
    }

    public UnitCenter getMinType() {
        return INCH;
    }

}
