package length;


public interface UnitCenter
{
    int getScale();
    UnitCenter getMinType();
}
