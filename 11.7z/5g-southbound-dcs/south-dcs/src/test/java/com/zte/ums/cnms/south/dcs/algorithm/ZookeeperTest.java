package com.zte.ums.cnms.south.dcs.algorithm;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.zkclient.ZKAPI;
import com.zte.ums.cnms.south.dcs.zookeeper.FakeZookeeper;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import org.apache.curator.test.TestingServer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


public class ZookeeperTest {

    TestingServer testingServer;
    Zookeeper zookeeper;

    @Before
    public void setUp() throws Exception {
        int port = 2288;
        testingServer = new TestingServer(port);
        ZKAPI.getZkClient().connect("localhost:" + port);
        zookeeper = Zookeeper.getInstance();
        zookeeper.setZkClient(ZKAPI.getZkClient());
    }

    @After
    public void tearDown() throws IOException {
        testingServer.stop();
        zookeeper = null;
    }

    @Test
    public void should_return_exception_when_get_PAdatper_error() {
        assertThat(zookeeper.getPAdaptor()).isEmpty();
    }

    @Test
    public void should_return_normal_when_input_normally() throws Exception {
        int adapterSize = 5;
        List<Adapter> adapterList = FakeZookeeper.getInstance().getFakePAdaptor(adapterSize);

        for (Adapter adapter : adapterList) {
            zookeeper.getZkClient().registerProtocolAdapterInstance(adapter);
        }

        assertThat(zookeeper.getPAdaptor().size()).isEqualTo(adapterSize);
    }

}