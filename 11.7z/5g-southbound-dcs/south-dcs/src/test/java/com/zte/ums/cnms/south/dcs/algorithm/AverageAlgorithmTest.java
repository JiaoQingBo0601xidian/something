package com.zte.ums.cnms.south.dcs.algorithm;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.dcs.topo.NFCache;
import com.zte.ums.cnms.south.dcs.zookeeper.FakeZookeeper;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class AverageAlgorithmTest {

    private List<NF> nfList;
    private Map<Adapter, List<NF>> result;
    private int adapterNumber = 3;
    private int MAX_NF = new Adapter("test","","","","",0).getCapacity();

    private void executeAlgorithm(int nfNumber, int adapterNumber){
        nfList = NFCache.createNF(nfNumber);
        List<Adapter> adapterList = FakeZookeeper.getInstance().getFakePAdaptor(adapterNumber);
        Algorithm average = new AverageAlgorithm();
        result = average.dispatch(nfList, adapterList);
    }

    @Test
    public void should_be_dispatched_average_when_nf_number_is_mutiple_adapter_number(){
        int nfNumber = MAX_NF * adapterNumber;

        executeAlgorithm(nfNumber, adapterNumber);

        int expected = nfNumber / adapterNumber;
        for(Map.Entry<Adapter, List<NF>> temp : result.entrySet()){
            assertThat(temp.getValue().size()).isEqualTo(expected);
            assertThat(temp.getKey().getRemain()).isEqualTo(MAX_NF - temp.getValue().size());
        }
        assertThat(nfList).isEmpty();
    }

    @Test
    public void should_be_dispatched_almost_average_when_nf_number_is_not_mutiple_adapter_number(){
        int nfNumber = MAX_NF * adapterNumber - 17;

        executeAlgorithm(nfNumber, adapterNumber);

        int expected = nfNumber / adapterNumber;
        for(Map.Entry<Adapter, List<NF>> temp : result.entrySet()){
            assertThat(temp.getValue().size()).isGreaterThanOrEqualTo(expected);
            assertThat(temp.getKey().getRemain()).isEqualTo(MAX_NF - temp.getValue().size());
        }
        assertThat(nfList).isEmpty();
    }

    @Test
    public void should_be_dispatched_almost_average_when_nf_number_is_less_than_adapter_number(){
        int nfNumber = adapterNumber - 1;

        executeAlgorithm(nfNumber, adapterNumber);

        for(Map.Entry<Adapter, List<NF>> temp : result.entrySet()){
            assertThat(temp.getValue().size()).isLessThanOrEqualTo(1);
            assertThat(temp.getKey().getRemain()).isEqualTo(MAX_NF - temp.getValue().size());
        }
        assertThat(nfList).isEmpty();
    }

    @Test
    public void should_be_dispatched_average_when_there_is_not_enough_adapter(){
        int more = 332;
        int nfNumber = MAX_NF * adapterNumber + more;

        executeAlgorithm(nfNumber, adapterNumber);

        int expected = MAX_NF;
        for(Map.Entry<Adapter, List<NF>> temp : result.entrySet()){
            assertThat(temp.getValue().size()).isEqualTo(expected);
            assertThat(temp.getKey().getRemain()).isEqualTo(MAX_NF - temp.getValue().size());
        }
        assertThat(nfList.size()).isEqualTo(more);
    }
}
