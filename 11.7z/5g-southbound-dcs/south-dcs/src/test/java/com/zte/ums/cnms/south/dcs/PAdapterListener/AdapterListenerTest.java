package com.zte.ums.cnms.south.dcs.PAdapterListener;

import com.zte.ums.cnms.south.api.zkclient.ZKClient;
import com.zte.ums.cnms.south.api.zkclient.ZKClientWatcherProvider;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.zookeeper.data.Stat;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 10198113 on 2016/5/25.
 */
public class AdapterListenerTest {
    PathChildrenCacheEvent event = mock(PathChildrenCacheEvent.class);
    ZKClient zkClient;
    CuratorFramework curatorFramework = mock(CuratorFramework.class);

    @Before
    public void setUp() throws Exception {
        zkClient = new ZKClient() {
            @Override
            public String getCurrentNodeData(CuratorFramework client, String currentpath) {
                return "{\"name\":\"adapter\"}";
            }


        };


        when(event.getData()).thenReturn(new ChildData(ZKClient.NetConf_Adapter + "/adapter", new Stat(), new byte[1]));
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testhandleChildUpdate() throws Exception {


    }
}