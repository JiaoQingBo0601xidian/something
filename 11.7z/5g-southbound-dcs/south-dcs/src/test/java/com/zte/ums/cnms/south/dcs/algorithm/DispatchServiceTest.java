package com.zte.ums.cnms.south.dcs.algorithm;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.exception.EventHandlerException;
import com.zte.ums.cnms.south.dcs.exception.ZookeeperException;
import com.zte.ums.cnms.south.dcs.topo.NFCache;
import com.zte.ums.cnms.south.dcs.zookeeper.FakeZookeeper;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.zte.ums.cnms.south.api.bean.EventObject.ADAPTER;
import static com.zte.ums.cnms.south.api.bean.EventObject.NF;
import static com.zte.ums.cnms.south.dcs.algorithm.AlgorithmType.AVERAGE;
import static com.zte.ums.cnms.south.dcs.bean.EventType.ADD;
import static com.zte.ums.cnms.south.dcs.bean.EventType.DELETE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DispatchServiceTest {
    private DispatchService dcs;
    private Adapter adapter;
    private List<Adapter> adapterList;
    private NFCache nfCache;
    private Zookeeper mockZookeeper;
    private int adapterCount;
    private int more;

    @Before
    public void setUp(){
        nfCache = NFCache.getInstance();
        dcs = DispatchService.getInstance();
        dcs.setAlgorithmType(AVERAGE);
        adapter = new Adapter("adapter", "", "", "", "", 0);
        mockZookeeper = mock(Zookeeper.class);
        dcs.setZookeeper(mockZookeeper);
        adapterCount = 2;
        adapterList = FakeZookeeper.getInstance().getFakePAdaptor(adapterCount);
        more = 100;
        when(mockZookeeper.getPAdaptor()).thenReturn(adapterList);
    }

    @After
    public void tearDown(){
        nfCache.clear();
    }

    private List<NF> addBatchNF(int count) {
        List<NF> nfList = new ArrayList<>();
        for (int index = 0; index < count; index++) {
            nfList.add(new NF("new" + index, "new" + index));
        }
        return nfList;
    }

    /**
     * 测试场景：批量增加6000个网元，此时剩余的可分配的协议适配器空闲管理能力只有2900，有100个网元未分配。
     * 验证条件：
     * 1、所有协议适配器管理能力都刚好被分满；
     * 2、待分配网元数量为100。
     */
    @Test
    public void should_partly_be_dispatched_when_add_batch_nf_and_there_is_not_enough_adapter() throws ZookeeperException, EventHandlerException {
        int initialNFCount = 100;
        initDispatch(initialNFCount);

        int newNFCount = adapter.getCapacity() * adapterCount - initialNFCount + more;
        List<NF> newNFs = addBatchNF(newNFCount);
        Event nfAddEvent = new Event(ADD, NF, newNFs);
        dcs.handleEvent(nfAddEvent);

        for (Adapter adapter : adapterList) {
            assertThat(adapter.getRemain()).isEqualTo(0);
        }
        assertThat(nfCache.getNotDispatchedNF().size()).isEqualTo(more);
    }

    /**
     * 测试场景：新增一个协议适配器，此时有待分配的网元100个，这些网元被分配给该协议适配器。
     * 验证条件：
     * 1、待分配网元数量为0；
     * 2、100个网元都被分配给新增的协议适配器。
     */
    @Test
    public void should_redispatch_when_add_one_Adapter_and_there_are_still_NFs_to_be_dispatched() throws ZookeeperException, EventHandlerException {
        int initialNFCount = adapter.getCapacity() * adapterCount + more;
        initDispatch(initialNFCount);
        assertThat(nfCache.getNotDispatchedNF().size()).isEqualTo(more);

        int newAdaperCount = 1;
        List<Adapter> newAdapterList = FakeZookeeper.getInstance().getFakePAdaptor(newAdaperCount);
        Event addAdapterEvent = new Event(ADD, ADAPTER, newAdapterList);
        when(mockZookeeper.getPAdaptor()).thenReturn(newAdapterList);
        dcs.handleEvent(addAdapterEvent);
        assertThat(nfCache.getNotDispatchedNF()).isEmpty();
        assertThat(newAdapterList.get(0).getRemain()).isEqualTo(adapter.getCapacity() - more);
    }

    private void initDispatch(int initialNFCount) throws ZookeeperException {
        nfCache.addNotDispatchedNF(NFCache.createNF(initialNFCount));
        dcs.initDispatch();
    }

    /**
     * 测试场景：删除一个协议适配器，该协议适配器下有100个网元。此时所有的协议适配器的空闲管理能力支持刚好支持100个网元，
     * 被删除的协议适配器下的100个网元被分配给空闲的协议适配器。分配后，所有协议适配器都被分满。
     * 验证条件：
     * 1、待分配网元数量为0；
     * 2、所有协议适配器管理能力都刚好被分满。
     */
    @Test
    public void should_redispatch_when_delete_one_Adapter() throws ZookeeperException, EventHandlerException {
        int initialNFCount = adapter.getCapacity() * adapterCount - more;
        initDispatch(initialNFCount);

        List<Adapter> deletedAdapters = new ArrayList<>();
        deletedAdapters.add(adapter);
        Event deleteAdapterEvent = new Event(DELETE, ADAPTER, deletedAdapters);
        when(mockZookeeper.getNF(adapter)).thenReturn(NFCache.createNF(more));
        dcs.handleEvent(deleteAdapterEvent);

        assertThat(nfCache.getNotDispatchedNF()).isEmpty();
        checkAdapterIsFull();
    }

    private void checkAdapterIsFull() {
        for (Adapter adapter : adapterList) {
            assertThat(adapter.getRemain()).isEqualTo(0);
        }
    }

    /**
     * 测试场景：删除70个网元，此时还有100个网元待分配。70个网元被删除后，100个待分配网元中的70个被分配给协议适配器。
     * 验证条件：
     * 1、待分配网元数量为30；
     * 2、所有协议适配器管理能力都刚好被分满。
     */
    @Test
    public void should_redispatch_when_delete_NFs() throws Exception, ZookeeperException {
        int initialNFCount = adapter.getCapacity() * adapterCount + more;
        initDispatch(initialNFCount);
        assertThat(nfCache.getNotDispatchedNF().size()).isEqualTo(more);

        int deletedNFCount = 70;
        List<NF> deletedNFList = NFCache.createNF(deletedNFCount);
        Event deleteNFEvent = new Event(DELETE, NF, deletedNFList);
        List<Adapter> adapterList = FakeZookeeper.getInstance().getFakePAdaptor(1);
        adapterList.get(0).setRemain(deletedNFList.size());
        this.adapterList.addAll(adapterList);
        dcs.handleEvent(deleteNFEvent);

        assertThat(nfCache.getNotDispatchedNF().size()).isEqualTo(more - deletedNFCount);
        checkAdapterIsFull();
    }

}