package com.zte.ums.cnms.south.dcs.mq;

import com.zte.ums.cnms.south.api.bean.Adapter;
import org.junit.Assert;
import org.junit.Test;
import com.zte.ums.cnms.south.dcs.bean.ActiveMqInfo;

import static org.hamcrest.core.Is.is;

public class ActiveMQCreaterTest {

    @Test
    public void should_return_activemqinfo() throws Exception {
        ActiveMQCreater creater = new ActiveMQCreater();
        ActiveMqInfo activeMqInfo = new ActiveMqInfo("10.63.212.34", "61616");
        ActiveMqCommon.setActiveMqIp("10.63.212.34");
        ActiveMqCommon.setActiveMqPort("61616");

        ActiveMqInfo actual = creater.getActiveMqInfo();

        Assert.assertThat(actual.getIp(), is(activeMqInfo.getIp()));
        Assert.assertThat(actual.getPort(), is(activeMqInfo.getPort()));
    }

    @Test
    public void should_return_PAwithMQQueue_when_input_PAwithoutMQQueue() throws Exception {

        Adapter pAdapter = new Adapter("testPA", "", "", "", "",3000);
        Adapter expected = new Adapter("testPA", "reqMQ", "resMQ", "1.1.1.1", "80",3000);

        ActiveMQCreater creater = new ActiveMQCreater();
        Adapter actual =  creater.createPadapterWithMqInfo(pAdapter);

    }

}