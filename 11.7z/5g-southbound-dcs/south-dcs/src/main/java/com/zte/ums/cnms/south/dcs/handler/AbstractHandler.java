package com.zte.ums.cnms.south.dcs.handler;

import com.google.common.base.Preconditions;
import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import com.zte.ums.cnms.south.dcs.algorithm.Algorithm;
import com.zte.ums.cnms.south.dcs.algorithm.DispatchService;
import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.exception.ZookeeperException;
import com.zte.ums.cnms.south.dcs.topo.NFCache;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractHandler<T> implements EventHandler<T>{
    private final Logger logger = PaaSLogService.getLogger(this.getClass());
    NFCache nfCache = NFCache.getInstance();
    Algorithm algorithm = DispatchService.getInstance().getAlgorithm();
    Zookeeper zookeeper = Zookeeper.getInstance();

    @Override
    public void setZookeeper(Zookeeper zookeeper) {
        this.zookeeper = zookeeper;
    }

    @Override
    public void process(Event<T> event) {
        switch (event.getType()){
            case ADD: add(event.getParam());
            case DELETE: delete(event.getParam());
        }
    }

    protected abstract void delete(List<T> param);

    protected abstract void add(List<T> param);

    protected Map<Adapter, List<NF>> redispatch() {
        Preconditions.checkArgument(zookeeper != null, "Field zookeeper is null but expected not null");
        Preconditions.checkArgument(nfCache != null, "Field nfCache is null but expected not null");
        Map<Adapter, List<NF>> result = algorithm.dispatch(nfCache.getNotDispatchedNF(), zookeeper.getPAdaptor());
        try {
            zookeeper.publish(result);
            return result;
        } catch (ZookeeperException e) {
            logger.warn("publish to zookeeper error! " + Arrays.toString(e.getStackTrace()));
            return new HashMap<>();
        }
    }
}
