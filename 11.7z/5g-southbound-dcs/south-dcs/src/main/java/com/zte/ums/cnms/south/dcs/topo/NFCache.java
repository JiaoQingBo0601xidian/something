package com.zte.ums.cnms.south.dcs.topo;


import com.zte.ums.cnms.south.api.bean.NF;

import java.util.ArrayList;
import java.util.List;

public class NFCache {
    private List<NF> notDispatchedNF = new ArrayList<>();
    private static NFCache instance = new NFCache();

    private NFCache(){}

    public static NFCache getInstance(){
        return instance;
    }

    public static List<NF> createNF(int count) {
        List<NF> nfList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            nfList.add(new NF(String.valueOf(i), String.valueOf(i)));
        }
        return nfList;
    }

    public List<NF> getNotDispatchedNF() {
        return notDispatchedNF;
    }

    public void addNotDispatchedNF(List<NF> nfList) {
        notDispatchedNF.addAll(nfList);
    }

    public void clear() {
        notDispatchedNF.clear();
    }
}
