package com.zte.ums.cnms.south.dcs.topo;

import java.util.List;

import com.zte.ums.cnms.south.api.bean.EventObject;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.dcs.algorithm.DispatchService;
import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.bean.EventType;
import com.zte.ums.cnms.south.dcs.exception.EventHandlerException;

import static com.zte.ums.cnms.south.api.bean.EventObject.NF;
import static com.zte.ums.cnms.south.dcs.bean.EventType.ADD;
import static com.zte.ums.cnms.south.dcs.bean.EventType.DELETE;

public class NFNodeChangeListener implements NodeChangeListener {
    private DispatchService dcs;
    private Event event;

    public NFNodeChangeListener(DispatchService dcs){
        this.dcs = dcs;
    }
    @Override
    public void onCreate(List<NF> nfList) {
        event = new Event(ADD, NF, nfList);
        try {
            this.dcs.handleEvent(event);
        } catch (EventHandlerException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDelete(List<NF> nfList) throws EventHandlerException {
        event = new Event(DELETE, NF, nfList);
        this.dcs.handleEvent(event);
    }
}
