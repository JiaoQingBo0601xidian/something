package com.zte.ums.cnms.south.dcs.mq;


import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import com.zte.ums.cnms.south.dcs.bean.ActiveMqInfo;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.assertj.core.util.Strings;
import org.slf4j.Logger;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Session;

import static com.zte.ums.cnms.south.api.constant.AdapterErrorCode.MQ_CREATED_FAIL;
import static com.zte.ums.cnms.south.dcs.common.DCSConstant.*;
import static java.lang.Boolean.*;
import static org.assertj.core.util.Strings.*;

public class ActiveMQCreater {

    private final Logger logger = PaaSLogService.getLogger(this.getClass());
    private static final String IP = "10.63.212.34";
    private static final String PORT = "61616";

    public Adapter createPadapterWithMqInfo(Adapter pa) throws JMSException {
        ActiveMqInfo info = getActiveMqInfo();
        if (isNullOrEmpty(pa.getResponseMq()) || isNullOrEmpty(pa.getRequestMq())) {
            createMq(info, pa);
            pa.setIp(info.getIp());
            pa.setPort(info.getPort());
            pa.setRequestMq(getReqMqName(pa));
            pa.setResponseMq(getResMqName(pa));
        }
        return pa;
    }

    public ActiveMqInfo getActiveMqInfo() {
//        return new ActiveMqInfo(getActiveMqIp(), getActiveMqPort());
        return new ActiveMqInfo(IP, PORT);
    }

    private void createMq(ActiveMqInfo activeMQInfo, Adapter adapter) throws JMSException {
        Connection connection = null;
        Session session = null;
        try {
            connection = getConnection(activeMQInfo);
            session = connection.createSession(TRUE, Session.AUTO_ACKNOWLEDGE);
            session.createProducer(session.createQueue(getResMqName(adapter)));
            session.createProducer(session.createQueue(getReqMqName(adapter)));
        } catch (JMSException e) {
            //// TODO: 16-5-12
            adapter.setStatus(MQ_CREATED_FAIL);
            logger.warn("create MQ queue failed: " + e);
            throw e;
        } finally {
            closeSessionAndConnection(connection, session);
        }
    }

    private void closeSessionAndConnection(Connection connection, Session session) {
        try {
            if (null != session) {
                session.close();
            }
            if (null != connection) {
                connection.close();
            }
        } catch (JMSException e) {
            //// TODO: 16-5-12
            logger.info("session close failed" + e);
        }
    }

    private Connection getConnection(ActiveMqInfo activeMQInfo) throws JMSException {
        Connection connection = getConnectionFactory(activeMQInfo).createConnection();
        connection.start();
        return connection;
    }

    private ConnectionFactory getConnectionFactory(ActiveMqInfo activeMQInfo) {
        String connect = FAILOVER_TCP + activeMQInfo.getIp() + ":" + activeMQInfo.getPort();
        return new ActiveMQConnectionFactory(ActiveMQConnection.DEFAULT_USER,
                ActiveMQConnection.DEFAULT_PASSWORD, connect);
    }

    private String getResMqName(Adapter pa) {
        return RES_MQ_PREFIX + "_" + pa.getName();
    }

    private String getReqMqName(Adapter pa) {
        return REQ_MQ_PREFIX + "_" + pa.getName();
    }

}
