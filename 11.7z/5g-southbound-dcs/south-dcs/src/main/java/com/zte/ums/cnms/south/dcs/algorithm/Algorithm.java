package com.zte.ums.cnms.south.dcs.algorithm;



import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;

import java.util.List;
import java.util.Map;

public interface Algorithm {
    Map<Adapter, List<NF>> dispatch(List<NF> NFList, List<Adapter> adaptorList);
}
