package com.zte.ums.cnms.south.dcs.topo;

import com.google.common.base.Optional;
import java.util.List;
import com.zte.ums.cnms.south.api.bean.NF;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/add")
@Produces(MediaType.APPLICATION_JSON)
public class AddNFResource {

    private int addNFCount=1;
    private NFNodeChangeListener listener;

    public AddNFResource(int c){
        this.addNFCount = c;
    }

    @GET
    public String addNF(@QueryParam("count")Optional<Integer> count) {
        List<NF> nfs = NFCache.createNF(count.or(addNFCount));
        if(listener != null){
            listener.onCreate(nfs);
        }
        return String.format("add %d nf", nfs.size());
    }

    public void registerListener(NFNodeChangeListener listener){
        this.listener = listener;
    }
}
