package com.zte.ums.cnms.south.dcs.wrapper;

import com.zte.ums.cnms.south.api.zkclient.ZKAPI;
import com.zte.ums.cnms.south.dcs.algorithm.DispatchService;
import com.zte.ums.cnms.south.dcs.PAdapterListener.AdapterWatcher;
import com.zte.ums.cnms.south.api.bean.ZKInfo;
import com.zte.ums.cnms.south.dcs.exception.ZookeeperException;
import com.zte.ums.cnms.south.dcs.topo.NFCache;
import com.zte.ums.cnms.south.dcs.topo.NFChangeApplication;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import io.dropwizard.Application;
import io.dropwizard.setup.Environment;

import static com.zte.ums.cnms.south.dcs.algorithm.AlgorithmType.AVERAGE;

public class DCSApplication extends Application<DCSConfiguration> {

    public static void main(String[] args) throws Exception {
        new DCSApplication().run(args);
    }

    @Override
    public void run(DCSConfiguration configuration, Environment environment) throws Exception {
        ZKInfo zkInfo = configuration.getZkInfo();

        new AdapterWatcher().watcherAdapter(configuration);

        int nfCount = configuration.getNFCount();
        NFCache.getInstance().addNotDispatchedNF(NFCache.createNF(nfCount));
        String zkURI = zkInfo.getIp() + ":" + zkInfo.getPort();
        ZKAPI zkapi = ZKAPI.getZkClient();
        zkapi.connect(zkURI);
        Zookeeper.getInstance().setZkClient(ZKAPI.getZkClient());
        Zookeeper.getInstance().setZkServerURL(zkURI);

        environment.jersey().register(Zookeeper.getInstance());
        DispatchService.getInstance().setAlgorithmType(AVERAGE);
        try {
            DispatchService.getInstance().initDispatch();
        } catch (ZookeeperException e) {
            //// TODO: 16-5-19
        }
        new NFChangeApplication().run(environment);
    }
}
