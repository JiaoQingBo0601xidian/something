package com.zte.ums.cnms.south.dcs.topo;

import com.zte.ums.cnms.south.dcs.algorithm.DispatchService;
import io.dropwizard.setup.Environment;

public class NFChangeApplication {
    public void run(Environment environment) throws Exception {
        NFNodeChangeListener listener = new NFNodeChangeListener(DispatchService.getInstance());
        AddNFResource addNFResource = new AddNFResource(1);
        addNFResource.registerListener(listener);
        DelNFResource delNFResource = new DelNFResource(1);
        delNFResource.registerListener(listener);
        environment.jersey().register(addNFResource);
        environment.jersey().register(delNFResource);
    }
}
