package com.zte.ums.cnms.south.dcs.handler;

import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;

public interface EventHandler<T> {
    void process(Event<T> event);
    void setZookeeper(Zookeeper zk);
}
