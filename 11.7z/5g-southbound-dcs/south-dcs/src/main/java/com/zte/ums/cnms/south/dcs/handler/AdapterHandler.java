package com.zte.ums.cnms.south.dcs.handler;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;

import java.util.ArrayList;
import java.util.List;

public class AdapterHandler extends AbstractHandler<Adapter> {

    @Override
    protected void delete(List<Adapter> param) {
        nfCache.addNotDispatchedNF(getIsolatedNF(param));
        redispatch();
    }

    @Override
    protected void add(List<Adapter> param) {

    }

    private List<NF> getIsolatedNF(List<Adapter> deletedAdapterList) {
        List<NF> isolatedNFList = new ArrayList<>();
        for (Adapter adapter : deletedAdapterList) {
            isolatedNFList.addAll(zookeeper.getNF(adapter));
        }
        return isolatedNFList;
    }

}
