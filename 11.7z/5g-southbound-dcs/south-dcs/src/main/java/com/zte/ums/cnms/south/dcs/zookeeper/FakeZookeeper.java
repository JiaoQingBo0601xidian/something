package com.zte.ums.cnms.south.dcs.zookeeper;

import com.zte.ums.cnms.south.api.annotation.ForTest;
import com.zte.ums.cnms.south.api.bean.Adapter;

import java.util.ArrayList;
import java.util.List;

@ForTest
public class FakeZookeeper {
    private static FakeZookeeper instance = new FakeZookeeper();
    private FakeZookeeper(){}

    public static FakeZookeeper getInstance(){
        return instance;
    }

    public List<Adapter> getFakePAdaptor(int count) {
        List<Adapter> adaptorList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            adaptorList.add(new Adapter(String.valueOf(i), "", "", "","",0));
        }
        return adaptorList;
    }
}
