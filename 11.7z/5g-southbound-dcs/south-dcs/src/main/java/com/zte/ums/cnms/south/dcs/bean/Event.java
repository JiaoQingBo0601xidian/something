package com.zte.ums.cnms.south.dcs.bean;



import com.zte.ums.cnms.south.api.bean.EventObject;

import java.util.List;

public class Event<T> {
    EventType type;
    EventObject object;
    List<T> parameter;


    public Event(EventType t, EventObject obj, List<T> param) {
        this.type = t;
        this.parameter = param;
        this.object = obj;
    }

    public EventType getType() {
        return type;
    }

    public List<T> getParam() {
        return parameter;
    }


    public EventObject getObjectType() {
        return object;
    }
}
