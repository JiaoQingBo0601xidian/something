package com.zte.ums.cnms.south.dcs.mq;

public class ActiveMqCommon {
    private static String ACTIVE_MQ_IP;
    private static String ACTIVE_MQ_PORT;

    public static String getActiveMqIp() {
        return ACTIVE_MQ_IP;
    }

    public static void setActiveMqIp(String activeMqIp) {
        ACTIVE_MQ_IP = activeMqIp;
    }

    public static String getActiveMqPort() {
        return ACTIVE_MQ_PORT;
    }

    public static void setActiveMqPort(String activeMqPort) {
        ACTIVE_MQ_PORT = activeMqPort;
    }
}
