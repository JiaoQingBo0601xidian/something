package com.zte.ums.cnms.south.dcs.topo;

import java.util.List;
import com.zte.ums.cnms.south.api.bean.NF;

public interface NodeChangeListener {
    void onCreate(List<NF> nfList);
    void onDelete(List<NF> nfList) throws Exception;
}
