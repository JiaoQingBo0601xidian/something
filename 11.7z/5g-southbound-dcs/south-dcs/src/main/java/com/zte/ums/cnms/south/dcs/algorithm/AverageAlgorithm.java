package com.zte.ums.cnms.south.dcs.algorithm;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AverageAlgorithm extends AbstractAlgorithm {
    private final Logger logger = PaaSLogService.getLogger(this.getClass());
    @Override
    public Map<Adapter, List<NF>> dispatch(List<NF> nfList, List<Adapter> adapterList) {
        Map<Adapter, List<NF>> result = init(adapterList);
        int nfNumber = nfList.size();
        if(verifyFailed(nfList, adapterList)){
            logger.warn("no nf or adapter to dispatch!");
            return result;
        }
        long start = System.currentTimeMillis();
        dispatch(nfList, result);
        long cost = System.currentTimeMillis() - start;
        logger.info(String.format("dispatch cost: %d ms. There are %d nf, %d adapter.%n"
                , cost, nfNumber, adapterList.size()));
        return result;
    }

    private Map<Adapter, List<NF>> init(List<Adapter> adapterList) {
        Map<Adapter, List<NF>> result = new HashMap<>();
        adapterList.stream().filter(adapter -> adapter.getRemain() > 0).forEach(adapter -> result.put(adapter, new ArrayList<>()));
        return result;
    }

    private void dispatch(List<NF> nfList, Map<Adapter, List<NF>> result) {
        List<Adapter> notFullAdapterList = new ArrayList<>();
        List<Adapter> fullAdapterList = new ArrayList<>();
        notFullAdapterList.addAll(result.keySet());
        List<NF> oldNFList;
        int batch;
        List<NF> dispatchedNFList;
        while(!nfList.isEmpty() && !notFullAdapterList.isEmpty()){
            batch = nfList.size() >= notFullAdapterList.size() ? nfList.size() / notFullAdapterList.size() : 1;
            for(Adapter adapter : notFullAdapterList){
                oldNFList = result.get(adapter);
                dispatchedNFList = dispatchNFtoAdapter(nfList, batch, adapter.getRemain());
                oldNFList.addAll(dispatchedNFList);
                addToFullAdapterList(fullAdapterList, dispatchedNFList.size(), adapter);
                nfList.removeAll(dispatchedNFList);
            }
            notFullAdapterList.removeAll(fullAdapterList);
        }
    }

    private void addToFullAdapterList(List<Adapter> fullAdapter, int size, Adapter adapter) {
        if(size == adapter.getRemain()){
            fullAdapter.add(adapter);
        }
        adapter.setRemain(adapter.getRemain() - size);
    }

    private boolean verifyFailed(List<NF> nfList, List<Adapter> adapterList) {
        return isEmpty(nfList) || isEmpty(adapterList);
    }

    private boolean isEmpty(List<?> list) {
        return list == null || list.isEmpty();
    }
}
