package com.zte.ums.cnms.south.dcs.handler;

import com.zte.ums.cnms.south.api.bean.NF;

import java.util.List;

public class NFHandler extends AbstractHandler<NF> {

    @Override
    protected void delete(List<NF> param) {
        zookeeper.delete(param);
        redispatch();
    }

    @Override
    protected void add(List<NF> param) {
        nfCache.addNotDispatchedNF(param);
        redispatch();
    }

}
