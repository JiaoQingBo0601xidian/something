package com.zte.ums.cnms.south.dcs.common;

public class DCSConstant {

    public final static String FAILOVER_TCP = "failover://tcp://";
    public final static String REQ_MQ_PREFIX = "SOUTH_MQ_REQ";
    public final static String RES_MQ_PREFIX = "SOUTH_MQ_RES";
}
