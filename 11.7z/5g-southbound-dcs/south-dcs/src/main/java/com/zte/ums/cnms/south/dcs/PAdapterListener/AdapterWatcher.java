package com.zte.ums.cnms.south.dcs.PAdapterListener;

import com.zte.ums.cnms.south.api.bean.ZKInfo;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import com.zte.ums.cnms.south.api.zkclient.ZKAPI;
import com.zte.ums.cnms.south.dcs.wrapper.DCSConfiguration;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import org.slf4j.Logger;

public class AdapterWatcher {
    private final Logger logger = PaaSLogService.getLogger(AdapterWatcher.class);

    public void watcherAdapter(DCSConfiguration configuration) {

        ZKAPI zkapi = Zookeeper.getInstance().getZkClient();
        try {
            zkapi.watchAdapterInstanceNodeChange(new AdapterListener(zkapi), ZKAPI.Root_NetConf_Adapter_Path);
        } catch (Exception e) {
            //// TODO: 16-5-13
            logger.warn("failed to add Child Node Change Wathcer,node path: " + ZKAPI.Root_NetConf_Adapter_Path);
        }
    }

    private String getConnectString(DCSConfiguration configuration) {
        ZKInfo zkInfo = configuration.getZkInfo();
        return zkInfo.getIp() + ":" + zkInfo.getPort();
    }
}
