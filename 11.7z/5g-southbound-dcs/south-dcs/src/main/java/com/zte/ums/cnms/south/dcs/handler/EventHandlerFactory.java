package com.zte.ums.cnms.south.dcs.handler;

import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.exception.EventHandlerException;

public class EventHandlerFactory {
    public static <T> EventHandler createEventHandler(Event<T> event) throws EventHandlerException {
        switch (event.getObjectType()){
            case NF: return new NFHandler();
            case ADAPTER: return new AdapterHandler();
            default: throw new EventHandlerException("not support event object type: " + event.getObjectType());
        }
    }


}
