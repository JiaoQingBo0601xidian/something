package com.zte.ums.cnms.south.dcs.algorithm;




import com.zte.ums.cnms.south.api.bean.NF;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractAlgorithm implements Algorithm{
    List<NF> dispatchNFtoAdapter(List<NF> nfList, int batch, int remain) {
        List<NF> temp = new ArrayList<>();
        for(int i = 0; i < Math.min(Math.min(batch, remain), nfList.size()); i++){
            temp.add(nfList.get(i));
        }
        return temp;
    }
}
