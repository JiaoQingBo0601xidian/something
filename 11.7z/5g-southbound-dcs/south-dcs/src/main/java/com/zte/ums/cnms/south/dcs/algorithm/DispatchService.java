package com.zte.ums.cnms.south.dcs.algorithm;


import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import com.zte.ums.cnms.south.dcs.bean.Event;
import com.zte.ums.cnms.south.dcs.exception.EventHandlerException;
import com.zte.ums.cnms.south.dcs.exception.ZookeeperException;
import com.zte.ums.cnms.south.dcs.handler.EventHandler;
import com.zte.ums.cnms.south.dcs.handler.EventHandlerFactory;
import com.zte.ums.cnms.south.dcs.topo.NFCache;
import com.zte.ums.cnms.south.dcs.zookeeper.Zookeeper;
import org.slf4j.Logger;

import java.util.List;

public class DispatchService {
    private static final DispatchService instance = new DispatchService();
    private final Logger logger = PaaSLogService.getLogger(this.getClass());
    private AlgorithmType type;
    private Algorithm algorithm;
    private Zookeeper zookeeper = Zookeeper.getInstance();

    private DispatchService() {
    }

    public static DispatchService getInstance() {
        return instance;
    }

    public void setAlgorithmType(AlgorithmType type) {
        this.type = type;
    }

    public Algorithm getAlgorithm() {
        return algorithm;
    }

    public void setZookeeper(Zookeeper zookeeper) {
        this.zookeeper = zookeeper;

    }

    public void initDispatch() throws ZookeeperException {
        logger.debug("nf count is " + NFCache.getInstance().getNotDispatchedNF().size());
        algorithm = AlgorithmFactory.createAlgorithm(type);
        List<Adapter> adapterList = zookeeper.getPAdaptor();
        logger.debug("adapter count is " + adapterList.size());
        zookeeper.publish(algorithm.dispatch(NFCache.getInstance().getNotDispatchedNF(), adapterList));
        logger.info("initial success!");
    }

    public void handleEvent(Event event) throws EventHandlerException {
        EventHandler handler = EventHandlerFactory.createEventHandler(event);
        handler.setZookeeper(zookeeper);
        handler.process(event);
    }


}