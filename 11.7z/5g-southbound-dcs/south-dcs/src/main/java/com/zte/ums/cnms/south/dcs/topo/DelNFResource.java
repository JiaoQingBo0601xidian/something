package com.zte.ums.cnms.south.dcs.topo;

import com.google.common.base.Optional;
import java.util.List;
import com.zte.ums.cnms.south.api.bean.NF;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/delete")
@Produces(MediaType.APPLICATION_JSON)
public class DelNFResource {
    private int delNFCount=1;
    private NFNodeChangeListener listener;

    public DelNFResource(int delNFCount) {
        this.delNFCount = delNFCount;
    }

    @GET
    public String delNF(@QueryParam("count")Optional<Integer> count) throws Exception {
        List<NF> nfList = randomGetNF(count.or(delNFCount));
        listener.onDelete(nfList);
        return String.format("delete %d NF", count.or(delNFCount));
    }

    private List<NF> randomGetNF(Integer count) {
        return NFCache.createNF(count);
    }

    public void registerListener(NFNodeChangeListener listener){
        this.listener = listener;
    }
}
