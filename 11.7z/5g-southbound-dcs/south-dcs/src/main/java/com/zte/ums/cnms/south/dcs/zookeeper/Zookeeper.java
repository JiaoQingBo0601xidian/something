package com.zte.ums.cnms.south.dcs.zookeeper;


import com.zte.ums.cnms.south.api.annotation.ForTest;
import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.bean.NF;
import com.zte.ums.cnms.south.api.log.PaaSLogService;
import com.zte.ums.cnms.south.api.utils.JSONConverter;
import com.zte.ums.cnms.south.api.utils.JacksonUtil;
import com.zte.ums.cnms.south.api.zkclient.ZKAPI;
import com.zte.ums.cnms.south.dcs.exception.ZookeeperException;
import org.slf4j.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Path("/zookeeper")
public class Zookeeper {
    private final Logger logger = PaaSLogService.getLogger(this.getClass());
    private ZKAPI zkClient;
    private String zkServerURL;
    private static Zookeeper instance = new Zookeeper();

    private Zookeeper() {}

    public static Zookeeper getInstance(){
        return instance;
    }

    public ZKAPI getZkClient() {
        return zkClient;
    }


    public void setZkServerURL(String zkServerURL) {
        this.zkServerURL = zkServerURL;
    }

    public void setZkClient(ZKAPI zkClient) {
        this.zkClient = zkClient;
    }

    public List<Adapter> getPAdaptor() {
        logger.debug("enter getPAdapter");
        try {
            return zkClient.getAdapterInstances(zkClient.getNetconfType());
        } catch (Exception e) {
            logger.warn(String.format("get adapter failed, zk server is %s", this.zkServerURL));
            return new ArrayList<>();
        }
    }

//    private <T> List<T> getBeanFromZookeeper(String rootPath, List<String> childNodeName, Class<T> cls) throws Exception {
//        String objectData;
//        T object;
//        List<T> objectList = new ArrayList<>();
//        for (String childName : childNodeName) {
//            objectData = zkClient.getCurrentNodeData(curatorClient, rootPath + "/" + childName);
//            object = JacksonUtil.jsonToBean(objectData, cls);
//            if (object != null) {
//                objectList.add(object);
//            }
//        }
//        return objectList;
//    }

    public void publish(Map<Adapter, List<NF>> nodeMap) throws ZookeeperException {
        if (!ZKAPI.getZkClient().registerRouterTree(nodeMap)) {
            String msg = "register node failed!";
            logger.warn(msg);
            throw new ZookeeperException(msg);
        }
    }

    @ForTest
    @GET
    public String printZookeeperTree() throws Exception {
        StringBuilder zookeeperTree = new StringBuilder();
        List<Adapter> adapters = this.getPAdaptor();
        composeAdapterTree(adapters, zookeeperTree);
        for (Adapter adapter : adapters) {
            List<NF> nfs = getNF(adapter);
            composeNFTree(adapter, nfs, zookeeperTree);
        }
        logger.debug(zookeeperTree.toString());
        return zookeeperTree.toString();
    }

    private void composeNFTree(Adapter adapter, List<NF> nfs, StringBuilder zookeeperTree) throws Exception {
        zookeeperTree.append(adapter.getName()).append("[");
        int index = 1;
        for (NF nf : nfs) {
            zookeeperTree.append(nf.getName())
                    .append(JacksonUtil.beanToJson(nf))
                    .append(",");
            index = adjustDisplay(zookeeperTree, index);
        }
        zookeeperTree.append("]").append("\n");
    }

    private int adjustDisplay(StringBuilder zookeeperTree, int index) {
        if (zookeeperTree.length() > index * 170) {
            zookeeperTree.append("\n");
            index++;
        }
        return index;
    }

    private void composeAdapterTree(List<Adapter> adapters, StringBuilder zookeeperTree) {
        for (Adapter adapter : adapters) {
            zookeeperTree.append(adapter.getName())
                    .append(JSONConverter.covertAdapter2Json(adapter))
                    .append("\n");
        }
    }

    public List<NF> getNF(Adapter adapter) {
        try {
            return zkClient.getNFNodes(adapter);
        } catch (Exception e) {
            logger.warn("get nfs error, adapter is %s, zk server is %s", adapter.getName(), this.zkServerURL);
            return new ArrayList<>();
        }
    }

    public void delete(List<NF> deletedNFList) {
        try {
            zkClient.unRegisterNF(deletedNFList);
        } catch (Exception e) {
            logger.warn(String.format("delete nfs failed, zk server is %s", this.zkServerURL));
        }
    }
}
