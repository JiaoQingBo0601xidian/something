package com.zte.ums.cnms.south.dcs.exception;

public class EventHandlerException extends Exception{
    public EventHandlerException(String msg) {
        super(msg);
    }
}
