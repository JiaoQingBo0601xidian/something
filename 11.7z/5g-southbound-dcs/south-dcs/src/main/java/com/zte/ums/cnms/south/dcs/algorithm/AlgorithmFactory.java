package com.zte.ums.cnms.south.dcs.algorithm;

public class AlgorithmFactory {
    public static Algorithm createAlgorithm(AlgorithmType type) {
        switch (type){
            case AVERAGE: return new AverageAlgorithm();
            default: return new AverageAlgorithm();
        }
    }
}
