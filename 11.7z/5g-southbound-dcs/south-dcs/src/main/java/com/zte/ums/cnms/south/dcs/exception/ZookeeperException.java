package com.zte.ums.cnms.south.dcs.exception;

public class ZookeeperException extends Throwable {
    public ZookeeperException(String msg) {
        super(msg);
    }
}
