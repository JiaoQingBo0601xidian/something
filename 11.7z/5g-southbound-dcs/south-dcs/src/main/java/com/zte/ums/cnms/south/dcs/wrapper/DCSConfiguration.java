package com.zte.ums.cnms.south.dcs.wrapper;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.zte.ums.cnms.south.dcs.bean.ActiveMqInfo;
import com.zte.ums.cnms.south.api.bean.ZKInfo;
import io.dropwizard.Configuration;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;


public class DCSConfiguration extends Configuration {

    @JsonProperty("mqConfig")
    @NotNull
    @Valid
    private ActiveMqInfo activeMqInfo;

    @JsonProperty("zkConfig")
    @NotNull
    @Valid
    private ZKInfo zkInfo;

    @JsonProperty("nfCount")
    @NotNull
    @Valid
    private int nfCount;

    public ZKInfo getZkInfo() {
        return zkInfo;
    }

    public ActiveMqInfo getActiveMqInfo() {
        return activeMqInfo;
    }

    public int getNFCount() {
        return nfCount;
    }
}
