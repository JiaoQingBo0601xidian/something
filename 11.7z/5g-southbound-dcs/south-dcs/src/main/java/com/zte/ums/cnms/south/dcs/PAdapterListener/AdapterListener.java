package com.zte.ums.cnms.south.dcs.PAdapterListener;

import com.zte.ums.cnms.south.api.bean.Adapter;
import com.zte.ums.cnms.south.api.zkclient.ZKAPI;
import com.zte.ums.cnms.south.api.zkclient.ZKNodeChildWatcherProvider;
import com.zte.ums.cnms.south.dcs.mq.ActiveMQCreater;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;

import javax.jms.JMSException;


public class AdapterListener extends ZKNodeChildWatcherProvider
{
    private ZKAPI zkClient;

    public AdapterListener(ZKAPI zkClient) {
        this.zkClient = zkClient;
    }

    @Override
    protected void handleChildAdded(PathChildrenCacheEvent event) {
        try {
            String currentPath = event.getData().getPath();
            Adapter currentNodeData = zkClient.getAdapterInstance(currentPath);
            zkClient.updateAdapterInstanceData(writeMqInfo2Adapter(currentNodeData));
        } catch (Exception e) {
            //// TODO: 16-5-13
        }
    }

    private Adapter writeMqInfo2Adapter(Adapter adapter) throws JMSException {
        return new ActiveMQCreater().createPadapterWithMqInfo(adapter);
    }

    @Override
    protected void handleConnectSuspended(PathChildrenCacheEvent event) {

    }

    @Override
    protected void handleConnectReconnected(PathChildrenCacheEvent event) {

    }

    @Override
    protected void handleConnectLost(PathChildrenCacheEvent event) {

    }

    @Override
    protected void handleChildUpdate(PathChildrenCacheEvent event) {

    }

    @Override
    protected void handleChildRemoved(PathChildrenCacheEvent event) {

    }
}
