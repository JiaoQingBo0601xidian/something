package com.zte.ums.cnms.south.dcs.bean;

public enum EventType {
    ADD, DELETE, MODIFY
}
