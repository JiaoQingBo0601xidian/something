package com.zte.ums.cnms.south.dcs.algorithm;

public enum AlgorithmType {
    AVERAGE
}
