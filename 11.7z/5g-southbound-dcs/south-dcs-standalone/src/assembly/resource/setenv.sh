#!/bin/sh


Main_Class="com.zte.ums.zenap.fm.active.FmActiveApp"
Main_JAR="fm-active.jar"
Main_Conf="conf/fm-active.yml"
APP_INFO="zenap-fm-active"
EXT_DIRS=$RUNHOME/../dropwizard-dependency/*:$RUNHOME/../fm-dependency/*
