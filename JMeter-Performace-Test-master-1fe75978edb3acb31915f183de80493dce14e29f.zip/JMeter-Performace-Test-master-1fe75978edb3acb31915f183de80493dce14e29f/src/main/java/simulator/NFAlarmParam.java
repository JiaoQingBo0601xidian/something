package simulator;


public enum NFAlarmParam
{
    NF_LOCATION("nf_location", "NetWorkSliceId=1,SubNetWork=1,NFId=1;"),
    ALARM_CODE("alarm_code", "12345678"),
    AlARM_COUNTS("alarm_count", "10"),
    SIMULATE_TYPE("simulate_type", "1");

    private String param;
    private String defaultValue;

    NFAlarmParam(String param, String defaultValue)
    {
        this.param = param;
        this.defaultValue = defaultValue;
    }

    public String getParam()
    {
        return param;
    }

    public String getDefaultValue()
    {
        return defaultValue;
    }
}
