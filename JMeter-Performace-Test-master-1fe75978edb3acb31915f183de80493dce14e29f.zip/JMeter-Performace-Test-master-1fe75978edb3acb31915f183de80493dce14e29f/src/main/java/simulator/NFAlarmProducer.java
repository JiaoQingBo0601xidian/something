package simulator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.log4j.Logger;

import java.util.Date;
import java.util.Properties;
import java.util.concurrent.Future;

public class NFAlarmProducer
{
    private static final Logger logger = Logger.getLogger(NFAlarmProducer.class.getName());

    private KafkaProducer<String, String> producer;
    private String topic;
    private String nfLocation;
    private String alarmCode;
    private int alarmCounts;

    public NFAlarmProducer()
    {
    }

    public NFAlarmProducer(JavaSamplerContext context)
    {
        initParameter(context);
    }

    private void initParameter(JavaSamplerContext context)
    {
        producer = new KafkaProducer<>(PropertiesConfig());
        topic = Const.TOPIC;
        nfLocation = context.getParameter(NFAlarmParam.NF_LOCATION.getParam());
        alarmCode = context.getParameter(NFAlarmParam.ALARM_CODE.getParam());
        alarmCounts = Integer.parseInt(context.getParameter(NFAlarmParam.AlARM_COUNTS.getParam()));
    }

    public void sendAlarms()
    {
        NFAlarmMessage message = new NFAlarmMessage("resType", nfLocation, "alarmSource", "resPosition",
                "subNet", "nf", Long.parseLong(alarmCode), new Date().getTime(), "7");
        String jsonMessage = convertToJson(message);
        for (int i = 0; i < alarmCounts; i++)
        {
            sendNFAlarm(jsonMessage);
        }
    }

    private void sendNFAlarm(String jsonMessage)
    {
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>(topic, jsonMessage);
        Future<RecordMetadata> response = producer.send(producerRecord);
        try
        {
            RecordMetadata recordMetadata = response.get(); // �õ����صĽ��
            logger.info("The message" + jsonMessage + " sent to topic:" + recordMetadata.topic() + ", partition:" +
                    recordMetadata.partition() + ", offset:" + recordMetadata.offset());
        }
        catch (Exception e)
        {
            logger.error("Sending message error!", e);
        }
    }

    private static String convertToJson(NFAlarmMessage message)
    {
        ObjectMapper mapper = new ObjectMapper();
        String jsonString = "";
        try
        {
            jsonString = mapper.writeValueAsString(message);
        }
        catch (JsonProcessingException e)
        {
            logger.error("Parsing object to json error!", e);
        }
        return jsonString;
    }

    private Properties PropertiesConfig()
    {
        Properties props = new Properties();
        // ָ��Ҫ���ӵ� broker, ����Ҫ�г����е� broker,�����������г� 2 �����Է�ĳ�� broker ����
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, Const.BOOTSTRAP_SERVERS_CONFIG);
        // ��Ϊ��ϢҪ�� JVM ���䣬������Ҫָ��ָ�����л�����ע�����л���Ҫ����Ϣ�ĸ�ʽ���
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, Const.VALUE_SERIALIZER_CLASS_CONFIG);
        // ��Ϣ key ���л���
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, Const.KEY_SERIALIZER_CLASS_CONFIG);
        return props;
    }

}
