package simulator;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NFAlarmMessage
{
    public NFAlarmMessage(String resType, String position, String alarmSource, String resPosition, String subNet,
            String nf, long code, long alarmRaisedTime, String timeZoneId)
    {
        this.resType = resType;
        this.position = position;
        this.alarmSource = alarmSource;
        this.resPosition = resPosition;
        this.subNet = subNet;
        this.nf = nf;
        this.code = code;
        this.alarmRaisedTime = alarmRaisedTime;
        this.timeZoneId = timeZoneId;
    }

    @JsonProperty(value = "restype")  //��Դ����
    private String resType;

    @JsonProperty(value = "position")  //�澯������λ��  NetWorkSliceId=1,SubNetWork=1,NFId=1;
    private String position;

    @JsonProperty(value = "alarmsource")  //�澯������λ��
    private String alarmSource;

    @JsonProperty(value = "resposition")  //�澯����λ�ö�Ӧ����Դ��Ϣ�����ڹ��� NFC=RRC,MS=MS1��Container=1
    private String resPosition;

    private String subNet;

    @JsonProperty(value = "nf")  //��Ԫ
    private String nf;

    @JsonProperty(value = "code")  //�澯��
    private long code;

    @JsonProperty(value = "alarmraisedtime")  //�澯����ʱ��
    private long alarmRaisedTime;

    @JsonProperty(value = "timezoneid")  //�澯��������Ԫ���ڵ�ʱ��
    private String timeZoneId;

    public void setPosition(String position)
    {
        this.position = position;
    }

    public void setCode(long code)
    {
        this.code = code;
    }
}
