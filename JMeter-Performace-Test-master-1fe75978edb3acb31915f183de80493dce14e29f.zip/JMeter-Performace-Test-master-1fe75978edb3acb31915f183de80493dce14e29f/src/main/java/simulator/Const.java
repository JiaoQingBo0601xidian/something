package simulator;

/**
 * Created by 00189971 on 2016/4/28.
 */
public class Const
{
    public static final String TOPIC = "alarmtopic";
    public static final String BOOTSTRAP_SERVERS_CONFIG = "10.92.252.249:9092,10.92.252.251:9990";
    public static final String VALUE_SERIALIZER_CLASS_CONFIG = "org.apache.kafka.common.serialization.StringSerializer";
    public static final String KEY_SERIALIZER_CLASS_CONFIG = "org.apache.kafka.common.serialization.StringSerializer";




    public static final String NF_DEFAULT_LOCATION = "NetWorkSliceId=1,SubNetWork=1,NFId=1";
    public static final String ALARM_CODE_DEFAULT = "12345678";
    public static final String ALARM_COUNTS_DEFAULT = "10";
}
