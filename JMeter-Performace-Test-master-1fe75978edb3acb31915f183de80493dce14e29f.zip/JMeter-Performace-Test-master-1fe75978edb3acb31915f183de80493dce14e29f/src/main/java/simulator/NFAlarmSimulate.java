package simulator;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.log4j.Logger;

import java.io.Serializable;

public class NFAlarmSimulate extends AbstractJavaSamplerClient implements Serializable
{
    private static final Logger logger = Logger.getLogger(NFAlarmSimulate.class.getName());

    @Override
    public SampleResult runTest(JavaSamplerContext context)
    {
        SampleResult results = new SampleResult();
        try
        {
            results.sampleStart();
            results.setSampleLabel("NF Alarm Simulate");
            new NFAlarmProducer(context).sendAlarms();
        }
        catch (Exception e)
        {
            logger.error("Jmeter run Test exception!", e);
        }
        finally
        {
            results.sampleEnd();
        }
        return results;
    }

    @Override
    public Arguments getDefaultParameters()
    {
        Arguments params = new Arguments();
        for (NFAlarmParam nfAlarmParam : NFAlarmParam.values())
        {
            params.addArgument(nfAlarmParam.getParam(), nfAlarmParam.getDefaultValue());
        }
        return params;
    }

}
