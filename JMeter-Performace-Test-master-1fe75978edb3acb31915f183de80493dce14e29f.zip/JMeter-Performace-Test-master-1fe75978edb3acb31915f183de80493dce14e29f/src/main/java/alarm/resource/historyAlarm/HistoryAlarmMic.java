package alarm.resource.historyAlarm;

import alarm.resource.ActiveAlarm.ActiveAlarmDB;
import alarm.util.AlarmConst;
import alarm.util.AlarmDBUtil;
import alarm.util.HttpRequest;
import org.apache.log4j.Logger;

/**
 * Created by 00189971 on 2016/4/14.
 */
public class HistoryAlarmMic implements HistoryAlarmDB
{
    String url;

    public HistoryAlarmMic(String url)
    {
        this.url = url;
    }

    @Override
    public long countAll()
    {
        String jsonResult = HttpRequest.sendRequest(url);
        return AlarmDBUtil.parseAlarmNumFromResponse(jsonResult);
    }
}
