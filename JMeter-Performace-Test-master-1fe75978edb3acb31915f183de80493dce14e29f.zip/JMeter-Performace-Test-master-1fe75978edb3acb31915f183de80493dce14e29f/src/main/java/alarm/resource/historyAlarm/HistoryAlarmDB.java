package alarm.resource.historyAlarm;

public interface HistoryAlarmDB
{
    long countAll();

}
