package alarm.resource.historyAlarm;

import org.apache.log4j.Logger;

public class HistoryAlarmCenter
{
    private static HistoryAlarmCenter instance = null;
    private HistoryAlarmDB dbResource = null;

    private static final org.apache.log4j.Logger logger = Logger.getLogger(HistoryAlarmCenter.class.getName());

    private HistoryAlarmCenter()
    {
    }

    public synchronized static HistoryAlarmCenter getInstance()
    {
        if (null == instance)
        {
            instance = new HistoryAlarmCenter();
        }
        return instance;
    }

    public void createHistoryAlarmDB(String dbIp, String dbType)
    {
        if (dbResource == null)
        {
            dbResource = new HistoryAlarmMic(dbIp);
        }
    }

    public long getAlarmNumFromDB()
    {
        return dbResource.countAll();
    }
}


