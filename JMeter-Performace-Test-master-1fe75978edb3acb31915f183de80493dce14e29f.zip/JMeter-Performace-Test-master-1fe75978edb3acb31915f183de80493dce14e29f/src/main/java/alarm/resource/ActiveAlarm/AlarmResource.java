package alarm.resource.ActiveAlarm;

import alarm.util.AlarmConst;
import alarm.util.AlarmDBUtil;
import alarm.util.HttpRequest;
import org.apache.log4j.Logger;

/**
 * Created by 00189971 on 2016/4/14.
 */
public class AlarmResource implements ActiveAlarmDB
{
    private static final Logger logger = Logger.getLogger(AlarmResource.class.getName());
    private String url;
    public AlarmResource()
    {
    }

    @Override
    public void createDB(String url)
    {
        this.url = url;
    }

    @Override
    public long countAll()
    {
        String jsonResult = HttpRequest.sendRequest(url);
        return AlarmDBUtil.parseAlarmNumFromResponse(jsonResult);
    }

    @Override
    public void store(String key, String value)
    {

    }

    @Override
    public String query(String key)
    {
        return null;
    }

    @Override
    public void delete(String key)
    {

    }

    @Override
    public boolean contains(String key)
    {
        return false;
    }

    @Override
    public void clearDB()
    {

    }
}
