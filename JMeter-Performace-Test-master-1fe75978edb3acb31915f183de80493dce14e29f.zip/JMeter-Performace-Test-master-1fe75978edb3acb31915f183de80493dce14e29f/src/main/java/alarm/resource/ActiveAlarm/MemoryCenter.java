package alarm.resource.ActiveAlarm;

import org.apache.log4j.Logger;

public class MemoryCenter
{
    private static MemoryCenter instance = null;
    private ActiveAlarmDB dbResource = null;

    private static final Logger logger = Logger.getLogger(AlarmResource.class.getName());

    private MemoryCenter()
    {

    }

    public synchronized static MemoryCenter getInstance()
    {
        if (null == instance)
        {
            instance = new MemoryCenter();
        }
        return instance;
    }

    public void store(String key, String value)
    {
        logger.debug(String.format("store data, key is:%s, value is:%s", key, value));
        if (null != key)
        {
            dbResource.store(key.toUpperCase(), value);
        }
    }

    public void createMemoryResource(String dbIp, String dbType) throws Exception
    {
        if (dbResource == null)
            createDBbyType(dbIp, dbType);
    }

    private void createDBbyType(String dbIp, String dbType) throws Exception
    {
        for (MemoryType memoryType : MemoryType.values())
        {
            if (memoryType.getDbType().equalsIgnoreCase(dbType))
            {
                dbResource = memoryType.getActiveAlarmDB();
                dbResource.createDB(dbIp);
            }
        }
    }

    public String query(String key)
    {
        if (dbResource != null)
        {
            return dbResource.query(key.toUpperCase());
        }

        return "{ \" key\": \"NO_RESULT\"}";
    }

    public void delete(String key)
    {
        if (dbResource != null)
        {
            dbResource.delete(key.toUpperCase());
        }
    }

    public boolean contains(String key)
    {
        return dbResource != null && dbResource.contains(key.toUpperCase());
    }

    public long getAlarmNumFromDB()
    {
        return dbResource.countAll();
    }

    public void clearDB()
    {
        dbResource.clearDB();
    }
}

enum MemoryType
{
    REDIS("Redis", new RedisResource()), MICRO_SERVICE("MicroService", new AlarmResource());
    private String dbType;
    private ActiveAlarmDB activeAlarmDB;

    MemoryType(String dbType, ActiveAlarmDB activeAlarmDB)
    {
        this.dbType = dbType;
        this.activeAlarmDB = activeAlarmDB;
    }

    public ActiveAlarmDB getActiveAlarmDB()
    {
        return activeAlarmDB;
    }

    public String getDbType()
    {
        return dbType;
    }
}
