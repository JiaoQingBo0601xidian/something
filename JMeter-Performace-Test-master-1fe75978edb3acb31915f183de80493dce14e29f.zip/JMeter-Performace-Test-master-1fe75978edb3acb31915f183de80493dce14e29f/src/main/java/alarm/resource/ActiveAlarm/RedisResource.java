package alarm.resource.ActiveAlarm;

import alarm.resource.ActiveAlarm.ActiveAlarmDB;
import redis.clients.jedis.Jedis;

public class RedisResource implements ActiveAlarmDB
{
    private Jedis jedis = null;

    public RedisResource()
    {
    }

    public void createDB(String ip)
    {
        jedis = new Jedis(ip);
    }

    public void store(String key, String value)
    {
        jedis.set(key, value);
    }

    synchronized public String query(String key)
    {
        return jedis.get(key);
    }

    public void delete(String key)
    {
        jedis.del(key);
    }

    synchronized public long countAll()
    {
        return jedis.dbSize();
    }

    synchronized public void clearDB()
    {
        jedis.flushDB();
    }


    public boolean contains(String key)
    {
        return jedis.exists(key);
    }
}

