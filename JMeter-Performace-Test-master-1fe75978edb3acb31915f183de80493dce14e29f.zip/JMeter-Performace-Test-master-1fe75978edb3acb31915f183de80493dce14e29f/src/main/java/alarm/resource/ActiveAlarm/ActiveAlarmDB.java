package alarm.resource.ActiveAlarm;

public interface ActiveAlarmDB
{
    void createDB(String url);

    void store(String key, String value);

    String query(String key);

    void delete(String key);

    boolean contains(String key);

    long countAll();

    void clearDB();
}
