package alarm.service;

import alarm.bean.Alarm;
import alarm.bean.AlarmEvent;
import alarm.bean.Location;
import alarm.bean.SctpLocation;
import alarm.util.HttpRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

import java.util.Date;

public class AlarmEventService
{
    private static final Logger logger = Logger.getLogger(AlarmEventService.class.getName());

    private Gson gson;
    public String subnetId;
    public int eventNum;
    private String eventId;
    private String eventStatus;
    private String url;
    private int repeatTime;
    private String peerLocation;

    public AlarmEventService(JavaSamplerContext context)
    {
        initParams(context);
    }

    private void initParams(JavaSamplerContext context)
    {
        gson = new GsonBuilder().disableHtmlEscaping().create();
        eventNum = context.getIntParameter(AlarmEventParam.EVENT_NUM.getParam());
        eventId = context.getParameter(AlarmEventParam.EVENT_ID.getParam());
        eventStatus = context.getParameter(AlarmEventParam.EVENT_STATUS.getParam());
        url = context.getParameter(AlarmEventParam.SERVER_URL.getParam());
        repeatTime = context.getIntParameter(AlarmEventParam.REPEAT_TIME.getParam());
        peerLocation = context.getParameter(AlarmEventParam.PEER_LOCATION.getParam());
        subnetId = context.getParameter(AlarmEventParam.SUBNET_ID.getParam());
    }

    public long SendEventByLocation(Location location)
    {
        long allBytes;
        String jsonEvent = createJsonEvent(location, eventId, "1", eventStatus, peerLocation);
        SendEventRepeatly(jsonEvent);
        allBytes = jsonEvent.getBytes().length * repeatTime;
        return allBytes;
    }

    private void SendEventRepeatly(String sctpEventJson)
    {
        for (int i = 0; i < repeatTime; i++)
        {
            String resultCode = HttpRequest.sendPost(url, sctpEventJson);
            logger.info("sending http resultCode is " + resultCode + "; message is " + sctpEventJson);
        }
    }

    private String createJsonEvent(Location location, String eventId, String eventType, String status,
            String peerLocation)
    {
        long traceId = createAlarmTraceId();
        AlarmEvent alarmEvent = new AlarmEvent(location, eventId, eventType, traceId, status,
                peerLocation);
        return gson.toJson(alarmEvent);
    }

    private long createAlarmTraceId()
    {
        return new Date().getTime();
    }

    public Alarm convert2Alarm(String eventMessage)
    {
        return gson.fromJson(eventMessage, new TypeToken<Alarm>()
        {
        }.getType());
    }

}
