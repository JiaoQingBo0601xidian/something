package alarm.service;

public enum AlarmEventParam
{

    SUBNET_ID("subnetId","999"),
    EVENT_NUM("eventNum", "1000"),
    SERVER_URL("url", "http://10.92.252.251/alarm"),
    REPEAT_TIME("repeatTime", "5"),
    CUR_DB_TYPE("curDBType", "microService"),
    CUR_ALARM_URL("curDBUrl", "http://10.74.65.150:12003/api/fm-active/v1/activealarms?queryrequest={\"pagesize\":1}"),
    HIS_DB_TYPE("hisDBType","microService"),
    HIS_ALARM_URL("hisDBUrl", "http://10.74.65.150:12004/api/fm-history/v1/hisalarms?queryrequest={\"pagesize\":1}"),
    EVENT_ID("eventId", "1"),
    EVENT_STATUS("eventStatus", "1"),
    PEER_LOCATION("peerLocation", "subnetID=2,meID=2");

    private String param;
    private String defaultValue;

    AlarmEventParam(String param, String defaultValue)
    {
        this.param = param;
        this.defaultValue = defaultValue;
    }

    public String getParam()
    {
        return param;
    }

    public void setParam(String value)
    {
        this.defaultValue = value;
    }

    public String getDefaultValue()
    {
        return defaultValue;
    }
}
