package alarm.service;

import alarm.bean.InitParam;
import alarm.bean.Location;
import alarm.bean.SctpLocation;
import alarm.pm.AlarmReportPm;
import alarm.pm.AlarmResumePm;
import alarm.pm.Performance;
import alarm.resource.ActiveAlarm.MemoryCenter;
import alarm.resource.historyAlarm.HistoryAlarmCenter;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

import java.util.List;

public class SctpEventsService extends AlarmEventService
{
    private static final Logger logger = Logger.getLogger(SctpEventsService.class.getName());

    public JavaSamplerContext context;
    public Performance performance;

    public SctpEventsService(JavaSamplerContext context)
    {
        super(context);
        this.context = context;
    }

    public String sctpAlarmRequest()
    {
        //���ݿ��ﵱǰ�ĸ澯��
        long origAlarmNum = MemoryCenter.getInstance().getAlarmNumFromDB();
        logger.info("There are " + origAlarmNum + " alarms before test.");

        //����ż���쳣�¼�
        long startTime = System.currentTimeMillis();
        long allBytesSend = SendSctpEvents();
        //��Ӧ������Ҫ�ĳ�ʼ������
        InitParam initParam = new InitParam(origAlarmNum, 0, startTime, allBytesSend);
        //�����ݿ����ѯ�Ƿ�����澯���Ҹ澯������ȷ
        performance = new AlarmReportPm(context);
        return performance.getPerformanceResult(initParam);
    }

    public String sctpAlarmResume()
    {
        long origCurAlarmNum = MemoryCenter.getInstance().getAlarmNumFromDB();
        logger.info("There are " + origCurAlarmNum + " alarms in cur alarm db before test.");

        long origHisAlarmNum = HistoryAlarmCenter.getInstance().getAlarmNumFromDB();
        logger.info("There are " + origHisAlarmNum + " alarms in history alarm db before test.");
        long startTime = System.currentTimeMillis();
        //����ż�������¼�
        long allBytesSend = SendSctpEvents();
        //��Ӧ������Ҫ�ĳ�ʼ������
        InitParam initParam = new InitParam(origCurAlarmNum, origHisAlarmNum, startTime, allBytesSend);
        //��ǰ�澯�Ƿ���������ʷ�澯�Ƿ������������ȷ
        performance = new AlarmResumePm(context);
        return performance.getPerformanceResult(initParam);

    }


    public long SendSctpEvents()
    {
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < eventNum; i++)
        {
            SctpLocation location = new SctpLocation(subnetId, String.valueOf(i), String.valueOf(i));
            //����ż�������¼�
            SendEventByLocation(location);
        }
        return startTime;
    }

}
