package alarm.util;

import alarm.resource.ActiveAlarm.MemoryCenter;
import alarm.resource.historyAlarm.HistoryAlarmCenter;
import alarm.service.AlarmEventParam;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AlarmDBUtil
{
    private static final Logger logger = Logger.getLogger(AlarmDBUtil.class.getName());

    public static MemoryCenter memoryCenter;
    public static HistoryAlarmCenter historyAlarmCenter;

    public static void initDB(JavaSamplerContext context)
    {

        initCurAlarmDB(context);
        initHisAlarmDB(context);

    }

    private static void initHisAlarmDB(JavaSamplerContext context)
    {
        historyAlarmCenter = HistoryAlarmCenter.getInstance();
        historyAlarmCenter.createHistoryAlarmDB(context.getParameter(AlarmEventParam.HIS_ALARM_URL.getParam()),
                AlarmEventParam.HIS_DB_TYPE.getParam());
        logger.info("init history alarm db successfully!");
    }

    private static void initCurAlarmDB(JavaSamplerContext context)
    {
        memoryCenter = MemoryCenter.getInstance();
        try
        {
            memoryCenter.createMemoryResource(context.getParameter(AlarmEventParam.CUR_ALARM_URL.getParam()),
                    context.getParameter(AlarmEventParam.CUR_DB_TYPE.getParam()));
        }
        catch (Exception e)
        {
            logger.error("create active db failed!", e);
            return;
        }
        logger.info("init active alarm db successfully!");
    }

    public static long parseAlarmNumFromResponse(String jsonResult)
    {
        try
        {
            Pattern p = Pattern.compile("[^0-9]");
            Matcher m = p.matcher(jsonResult.split(AlarmConst.TOTAL_COUNT)[1]);
            return Long.parseLong(m.replaceAll(""));
        }
        catch (Exception e)
        {
            logger.error("Parse http response error! The response result is " + jsonResult, e);
            return 0;
        }

    }
}
