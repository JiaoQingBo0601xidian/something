package alarm.util;

/**
 * Created by 00189971 on 2016/4/14.
 */
public class AlarmConst
{
    public static final String TOTAL_COUNT = "\"totalcount\":";

    public static final String REPORT_STATUES = "1";
    public static final String RESUME_STATUES = "0";

    public static final String DOUBLE_PATTERN = "0.00";
}
