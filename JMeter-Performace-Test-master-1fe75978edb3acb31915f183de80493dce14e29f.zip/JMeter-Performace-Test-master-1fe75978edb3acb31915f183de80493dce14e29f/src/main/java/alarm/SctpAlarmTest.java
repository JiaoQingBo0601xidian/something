package alarm;

import alarm.service.AlarmEventParam;
import alarm.service.SctpEventsService;
import alarm.util.AlarmConst;
import alarm.util.AlarmDBUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import java.io.File;
import java.io.Serializable;

/**
 * Created by 00189971 on 2016/4/6.
 */
public class SctpAlarmTest extends AbstractJavaSamplerClient implements Serializable
{
    private static final Logger logger = Logger.getLogger(SctpAlarmTest.class.getName());

    static
    {
        DOMConfigurator.configure(System.getProperty("user.dir") + File.separator + "resource" + File.separator
                + "log4j.xml");
    }

    @Override
    public void setupTest(JavaSamplerContext context)
    {
        AlarmDBUtil.initDB(context);
    }

    @Override
    public SampleResult runTest(JavaSamplerContext context)
    {
        SampleResult results = new SampleResult();
        try
        {
            results.sampleStart();
            logger.info("stcp event");
            String result = "";
            String eventStatus = context.getParameter(AlarmEventParam.EVENT_STATUS.getParam());
            if (AlarmConst.REPORT_STATUES.equals(eventStatus))
            {
                result = new SctpEventsService(context).sctpAlarmRequest();
            }
            else
            {
                result = new SctpEventsService(context).sctpAlarmResume();
            }

            results.setSampleLabel("SCTP");
            results.setResponseMessage(result);
            results.setSamplerData(result);
            if (StringUtils.isEmpty(result))
                results.setSuccessful(false);
            else
                results.setSuccessful(true);
            logger.info("stcp test finished!");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            results.sampleEnd();
        }
        return results;
    }

    @Override
    public Arguments getDefaultParameters()
    {
        Arguments params = new Arguments();
        for (AlarmEventParam alarmEventParam : AlarmEventParam.values())
        {
            params.addArgument(alarmEventParam.getParam(), alarmEventParam.getDefaultValue());
        }
        return params;
    }

}
