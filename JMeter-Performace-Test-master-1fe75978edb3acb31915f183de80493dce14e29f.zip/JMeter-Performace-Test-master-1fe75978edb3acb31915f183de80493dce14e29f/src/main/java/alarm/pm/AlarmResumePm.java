package alarm.pm;

import alarm.bean.InitParam;
import alarm.resource.ActiveAlarm.MemoryCenter;
import alarm.resource.historyAlarm.HistoryAlarmCenter;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

/**
 * Created by 00189971 on 2016/4/18.
 */
public class AlarmResumePm extends Performance
{
    private static final Logger logger = Logger.getLogger(AlarmResumePm.class.getName());

    public AlarmResumePm(JavaSamplerContext context)
    {
        super(context);
    }

    public String getPerformanceResult(InitParam initParam)
    {

        String result;
        int retry = 0;
        while (true)
        {
            try
            {
                //�ڹ��ܿ��õ�ǰ���£����������Ե�ʱ�����ıȽ�������������˯�ߵ�ʱ����Խϳ�һ�㣬ȡ�����ԵĴ���
                Thread.sleep(1000);
                if (checkIfResumeExpectedAlarmNums(initParam.getInitCurAlarmNum(), initParam.getInitHisAlarmNum()))
                {
                    result = calculatePm(initParam.getStartTime(), initParam.getAllBytesSend());
                    result = result + "  Now active alarm num is " + MemoryCenter.getInstance().getAlarmNumFromDB() +
                            ",History alarm num is " + HistoryAlarmCenter.getInstance().getAlarmNumFromDB();
                    break;
                }
                if (retry == 10)
                {
                    result = "Retry 10 times but did not get expect alarm num. Now active alarm num is " +
                            MemoryCenter.getInstance().getAlarmNumFromDB() + ",History alarm num is " +
                            HistoryAlarmCenter.getInstance().getAlarmNumFromDB();
                    break;
                }
                retry++;
            }
            catch (Exception e)
            {
                logger.error("Get alarm counts from db error!", e);
            }
        }
        return result;
    }

    private boolean checkIfResumeExpectedAlarmNums(long origCurAlarmNum, long origHisAlarmNum)
    {
        return ifDeleteExpectedCurAlarmNums(origCurAlarmNum) && ifGetExpectedHisAlarmNums(origHisAlarmNum);
    }

}
