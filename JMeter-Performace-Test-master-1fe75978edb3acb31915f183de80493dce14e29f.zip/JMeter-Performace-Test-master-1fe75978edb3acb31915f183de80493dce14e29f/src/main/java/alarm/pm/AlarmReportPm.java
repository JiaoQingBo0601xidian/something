package alarm.pm;

import alarm.bean.InitParam;
import alarm.resource.ActiveAlarm.MemoryCenter;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

/**
 * Created by 00189971 on 2016/4/18.
 */
public class AlarmReportPm extends Performance
{
    private static final Logger logger = Logger.getLogger(AlarmReportPm.class.getName());

    public AlarmReportPm(JavaSamplerContext context)
    {
        super(context);
    }

    public String getPerformanceResult(InitParam initParam)
    {

        String result;
        int retry = 0;
        while (true)
        {
            try
            {
                Thread.sleep(1000);
                if (ifGetExpectedCurAlarmNums(initParam.getInitCurAlarmNum()))
                {
                    result = calculatePm(initParam.getStartTime(), initParam.getAllBytesSend());
                    result = result + "Now alarm num is " + MemoryCenter.getInstance().getAlarmNumFromDB();
                    break;
                }
                if (retry == 10)
                {
                    result = "Retry 10 times but did not get expect alarm num.Now alarm num is " +
                            MemoryCenter.getInstance().getAlarmNumFromDB();
                    logger.info(result);
                    break;
                }
                retry++;
            }
            catch (Exception e)
            {
                logger.error("Get alarm counts from db error!", e);
            }
        }
        return result;
    }
}
