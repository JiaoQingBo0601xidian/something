package alarm.pm;

import alarm.bean.InitParam;
import alarm.resource.ActiveAlarm.MemoryCenter;
import alarm.resource.historyAlarm.HistoryAlarmCenter;
import alarm.service.AlarmEventParam;
import alarm.util.AlarmConst;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.log4j.Logger;

import java.text.DecimalFormat;

public abstract class Performance
{
    private static final Logger logger = Logger.getLogger(Performance.class.getName());

    private int eventNum;
    private int repeatTime;
    private String curAlarmUrl;
    private String hisAlarmUrl;

    public Performance(JavaSamplerContext context)
    {
        this.eventNum = context.getIntParameter(AlarmEventParam.EVENT_NUM.getParam());
        this.repeatTime = context.getIntParameter(AlarmEventParam.REPEAT_TIME.getParam());
        this.curAlarmUrl = context.getParameter(AlarmEventParam.CUR_ALARM_URL.getParam());
        this.hisAlarmUrl = context.getParameter(AlarmEventParam.HIS_ALARM_URL.getParam());
    }

    public abstract String getPerformanceResult(InitParam initParam);

    public boolean ifGetExpectedCurAlarmNums(long origAlarmNum)
    {
        long curAlarmSize = MemoryCenter.getInstance().getAlarmNumFromDB();
        return (curAlarmSize - origAlarmNum == eventNum);
    }

    public boolean ifGetExpectedHisAlarmNums(long origAlarmNum)
    {
        long curAlarmSize = HistoryAlarmCenter.getInstance().getAlarmNumFromDB();
        return (curAlarmSize - origAlarmNum == eventNum);
    }

    public boolean ifDeleteExpectedCurAlarmNums(long origAlarmNum)
    {
        long curAlarmSize = MemoryCenter.getInstance().getAlarmNumFromDB();
        return (origAlarmNum - curAlarmSize == eventNum);
    }

    public String calculatePm(long startTime, long allBytesSend)
    {
        int totalRequestEvent = getTotalRequestNum();
        long ellapsed = System.currentTimeMillis() - startTime;

        String mbPerSec = new DecimalFormat(AlarmConst.DOUBLE_PATTERN).format(
                1000.0D * (double) allBytesSend / (double) ellapsed / 1048576.0D);
        String avgAlarmPerSec = new DecimalFormat(AlarmConst.DOUBLE_PATTERN).format(1000.0D * (double) eventNum / (double) ellapsed);
        String result =
                 avgAlarmPerSec + " alarms/sec (" + mbPerSec + " MB/sec) Total Event is " +
                        totalRequestEvent +
                        ". Cost time " + (ellapsed / 1000) + " seconds";
        logger.info(result);
        return result;
    }

    public int getTotalRequestNum()
    {
        return eventNum * repeatTime;
    }

    public String getCurAlarmUrl()
    {
        return curAlarmUrl;
    }

    public String getHisAlarmUrl()
    {
        return hisAlarmUrl;
    }
}
