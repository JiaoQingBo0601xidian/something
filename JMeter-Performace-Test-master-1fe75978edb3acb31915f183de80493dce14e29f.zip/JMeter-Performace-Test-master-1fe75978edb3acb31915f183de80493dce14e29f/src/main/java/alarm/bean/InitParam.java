package alarm.bean;

/**
 * Created by 00189971 on 2016/4/18.
 */
public class InitParam
{
    long initCurAlarmNum;
    long initHisAlarmNum;
    long startTime;
    long allBytesSend;

    public InitParam(long initCurAlarmNum, long initHisAlarmNum, long startTime, long allBytesSend)
    {
        this.initCurAlarmNum = initCurAlarmNum;
        this.initHisAlarmNum = initHisAlarmNum;
        this.startTime = startTime;
        this.allBytesSend = allBytesSend;
    }

    public long getInitCurAlarmNum()
    {
        return initCurAlarmNum;
    }

    public long getInitHisAlarmNum()
    {
        return initHisAlarmNum;
    }

    public long getStartTime()
    {
        return startTime;
    }

    public long getAllBytesSend()
    {
        return allBytesSend;
    }
}
