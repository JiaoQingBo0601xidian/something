package alarm.bean;

/**
 * Created by 00189971 on 2016/4/6.
 */
public class SctpLocation extends Location
{
    private String sctpID;

    public SctpLocation(String subnetId, String meId, String sctpID)
    {
        super(subnetId, meId);
        this.sctpID = sctpID;
    }

    public String getLocationString()
    {
        return "subnetID=" + subnetID + ",meID=" + meID + ",sctpID=" + sctpID;
    }
}
