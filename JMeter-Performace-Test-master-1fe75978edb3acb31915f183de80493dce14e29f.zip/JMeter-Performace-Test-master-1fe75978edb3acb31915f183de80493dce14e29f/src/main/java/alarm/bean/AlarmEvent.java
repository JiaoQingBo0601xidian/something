package alarm.bean;

/**
 * Created by 00189971 on 2016/4/6.
 */
public class AlarmEvent
{
    private Location location;
    private String eventID;
    private String eventType;
    private long traceId;
    private Detail detail;

    public AlarmEvent(Location location, String eventID, String eventType, long traceId, String status,
            String peerLocation)
    {
        this.location = location;
        this.eventID = eventID;
        this.eventType = eventType;
        this.traceId = traceId;
        this.detail = new Detail(status, peerLocation);
    }
}

class Detail
{
    private String status;
    private String peerLocation;

    Detail(String status, String peerLocation)
    {
        this.status = status;
        this.peerLocation = peerLocation;
    }
}
