package alarm.bean;

/**
 * Created by 00189971 on 2016/4/7.
 */
public class Alarm
{
    private String alarmKey;
    private String position1;
    private String additionalText;

    public Alarm(String alarmKey, String position1, String additionalText)
    {
        this.alarmKey = alarmKey;
        this.position1 = position1;
        this.additionalText = additionalText;
    }

    public String getAlarmKey()
{
    return alarmKey;
}

    public void setAlarmKey(String alarmKey)
    {
        this.alarmKey = alarmKey;
    }

    public String getPosition1()
    {
        return position1;
    }

    public void setPosition1(String position1)
    {
        this.position1 = position1;
    }

    public String getAdditionalText()
    {
        return additionalText;
    }

    public void setAdditionalText(String additionalText)
    {
        this.additionalText = additionalText;
    }
}
