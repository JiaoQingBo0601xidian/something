package alarm.bean;

/**
 * Created by 00189971 on 2016/4/6.
 */
public class Location
{
    public String subnetID;
    public String meID;

    public Location(String subnetID, String meID)
    {
        this.subnetID = subnetID;
        this.meID = meID;
    }

    public String getLocationString()
    {
        return "subnetID=" + subnetID + ",meID=" + meID;
    }
}
