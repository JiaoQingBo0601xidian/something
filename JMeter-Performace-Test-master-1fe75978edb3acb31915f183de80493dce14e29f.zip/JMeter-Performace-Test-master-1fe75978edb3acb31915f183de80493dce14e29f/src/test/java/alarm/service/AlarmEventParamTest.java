package alarm.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class AlarmEventParamTest
{

    @Test
    public void testSetParam() throws Exception
    {


        for (AlarmEventParam alarmEventParam : AlarmEventParam.values())
        {
            System.out.println(alarmEventParam.getParam() + " : " + alarmEventParam.getDefaultValue());
        }
    }
}