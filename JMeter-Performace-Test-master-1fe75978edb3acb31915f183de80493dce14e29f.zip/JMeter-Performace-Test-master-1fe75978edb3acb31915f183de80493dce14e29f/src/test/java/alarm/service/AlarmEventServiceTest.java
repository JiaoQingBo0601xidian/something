package alarm.service;

import org.junit.Test;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class AlarmEventServiceTest
{
    @Test
    public void test()
    {
        String avgAlarmPerSec = new DecimalFormat("0.00").format( (double) 100 / (double) 123);
        System.out.println(avgAlarmPerSec);

        Size size = Enum.valueOf(Size.class, "SMALL");
        System.out.println(size.toString());
        System.out.println(size.ordinal());
        System.out.println(size.getS());
        System.out.println(Size.LARGE.compareTo(Size.SMALL));
        DecimalFormat df = (DecimalFormat) NumberFormat.getInstance();
        System.out.println(df.format(0.0063424));
    }
}

enum Size
{
    SMALL("S"), LARGE("L");

    Size(String s)
    {
        this.s = s;
    }

    public String getS()
    {
        return s;
    }

    String s;
}