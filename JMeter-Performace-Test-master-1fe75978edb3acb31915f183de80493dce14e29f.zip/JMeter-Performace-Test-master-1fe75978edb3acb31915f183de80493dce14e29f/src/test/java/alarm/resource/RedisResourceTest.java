package alarm.resource;

import alarm.resource.ActiveAlarm.MemoryCenter;
import alarm.util.AlarmDBUtil;
import org.junit.Test;

import static org.junit.Assert.*;

public class RedisResourceTest
{
    MemoryCenter memoryCenter = MemoryCenter.getInstance();

    @Test
    public void testStore() throws Exception
    {
        memoryCenter.store("1", "2");
        assertTrue(memoryCenter.contains("1"));
    }


    @Test
    public void testDelete() throws Exception
    {
        memoryCenter.delete("1");
        assertFalse(memoryCenter.contains("1"));

    }

    @Test
    public void testClear() throws Exception
    {
        memoryCenter.clearDB();
        assertEquals(0, memoryCenter.getAlarmNumFromDB());

    }
}