import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;


public class ParkingLotTest {
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Test
    public void should_can_park_car_when_parkinglot_is_not_full() throws ParkingLotException {
        List<ParkingLot> parkingLots=new ArrayList<>();
        ParkingLot parkLot=new ParkingLot(5);
        parkingLots.add(parkLot);
        Car car=new Car("10001");
        Admin admin=new Admin(parkingLots);
        admin.park(car.getCarId(),car,ParkingAlgorithm.MAX_REMAIN);
        assertEquals(admin.depart("10001"),true);

    }
    @Test
    public void should_can_not_park_car_when_parkinglot_is_full() throws ParkingLotException {
        expectedEx.expect(ParkingLotException.class);
        expectedEx.expectMessage("停车场满了");
        List<ParkingLot> parkingLots=new ArrayList<>();
        ParkingLot parkLot=new ParkingLot(1);
        parkingLots.add(parkLot);
        Car car=new Car("10001");
        Car car1=new Car("10002");
        Admin admin=new Admin(parkingLots);
        admin.park(car.getCarId(),car,ParkingAlgorithm.MAX_REMAIN);
        admin.park(car1.getCarId(),car1,ParkingAlgorithm.MAX_REMAIN);

    }

    @Test
    public void should_can_not_depart_car_when_a_car_is_not_park_in_the_parkinglot() throws ParkingLotException {
       expectedEx.expect(ParkingLotException.class);
       expectedEx.expectMessage("不存在这辆车");
        List<ParkingLot> parkingLots=new ArrayList<>();
        ParkingLot parkLot=new ParkingLot(5);
        parkingLots.add(parkLot);
        Admin admin=new Admin(parkingLots);
        admin.depart("10003");

    }


    @Test
    public void should_park_car_in_the_parkinglot_which_has_more_remain_when_a_car_is_park_in_the_parkinglot() throws ParkingLotException {

        List<ParkingLot> parkingLots=new ArrayList<>();
        ParkingLot parkLot1=new ParkingLot(1);
        ParkingLot parkLot2=new ParkingLot(2);
        ParkingLot parkLot3=new ParkingLot(3);
        ParkingLot parkLot4=new ParkingLot(4);
        parkingLots.add(parkLot1);
        parkingLots.add(parkLot2);
        parkingLots.add(parkLot3);
        parkingLots.add(parkLot4);
        Admin admin=new Admin(parkingLots);
        Car car=new Car("10001");
        admin.park(car.getCarId(),car,ParkingAlgorithm.MAX_REMAIN);

        assertEquals(parkLot1.getCars().size(),0);
        assertEquals(parkLot2.getCars().size(),0);
        assertEquals(parkLot3.getCars().size(),0);
        assertEquals(parkLot4.getCars().size(),1);

    }



    @Test
    public void should_park_car_in_the_parkinglot_which_has_more_ratio_remain_when_a_car_is_park_in_the_parkinglot() throws ParkingLotException {

        List<ParkingLot> parkingLots=new ArrayList<>();
        ParkingLot parkLot1=new ParkingLot(4);
        ParkingLot parkLot2=new ParkingLot(4);
        ParkingLot parkLot3=new ParkingLot(4);
        ParkingLot parkLot4=new ParkingLot(4);
        parkingLots.add(parkLot1);
        parkingLots.add(parkLot2);
        parkingLots.add(parkLot3);
        parkingLots.add(parkLot4);
        Admin admin=new Admin(parkingLots);

        Car car1=new Car("10001");
        Car car2=new Car("10002");
        Car car3=new Car("10003");
        Car car4=new Car("10004");
        Car car5=new Car("10005");
        Car car6=new Car("10006");


        admin.park(car1.getCarId(),car1,ParkingAlgorithm.MAX_RATIO_REMAIN);
        admin.park(car2.getCarId(),car2,ParkingAlgorithm.MAX_RATIO_REMAIN);
        admin.park(car3.getCarId(),car3,ParkingAlgorithm.MAX_RATIO_REMAIN);
        admin.park(car4.getCarId(),car4,ParkingAlgorithm.MAX_RATIO_REMAIN);
        assertEquals(parkLot1.getCars().size(),1);
        assertEquals(parkLot2.getCars().size(),1);
        assertEquals(parkLot3.getCars().size(),1);
        assertEquals(parkLot4.getCars().size(),1);


    }





}
