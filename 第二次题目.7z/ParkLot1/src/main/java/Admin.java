import java.util.List;

public class Admin {
    private List<ParkingLot> parkingLots;


    public Admin(List<ParkingLot> parkLots) {
        this.parkingLots = parkLots;
    }

    public void park(String id, Car car,ParkingAlgorithm parkingAlgorithm) throws ParkingLotException {
        ParkingLot beingChoosen = null;
        int max= 0;
        for (ParkingLot parkingLot : parkingLots) {
            int capacity = parkingLot.getCapacity();
            int used=parkingLot.getCars().size();
            int remain=capacity-used;
            switch (parkingAlgorithm)
            {
                case MAX_REMAIN:

                    if(max<remain)
                    {
                        max = remain;
                        beingChoosen=parkingLot;
                    }
                    break;
                case MAX_RATIO_REMAIN:
                    int ratio=remain/capacity;
                    if(max<ratio)
                    {
                        max=ratio;
                        beingChoosen=parkingLot;
                    }

            }





        }

        if (max > 0) {
            beingChoosen.add(id, car);
            return;
        }


        throw new ParkingLotException("停车场满了");
    }

    public boolean depart(String id) throws ParkingLotException {
        boolean result = false;
        for (ParkingLot parkingLot : parkingLots) {
            if (parkingLot.delete(id) == true) {
                return true;
            }
        }

        throw new ParkingLotException("不存在这辆车");


    }

}
