/**
 * Created by 10198118 on 2016/6/22.
 */
public enum ParkingAlgorithm {
    MAX_REMAIN,MAX_RATIO_REMAIN
}
