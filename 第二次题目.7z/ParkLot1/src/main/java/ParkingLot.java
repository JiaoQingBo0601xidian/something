import java.util.HashMap;
import java.util.Map;


public class ParkingLot {
    private Map<String,Car> cars=new HashMap<>();

    private int capacity=5;

    public Map<String, Car> getCars() {

        return cars;
    }

    public void setCars(Map<String, Car> cars) {
        this.cars = cars;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public ParkingLot(int capacity) {
         this.capacity=capacity;
    }

    public void add(String id, Car car) throws ParkingLotException {
        if(id!=null&&cars.get(id)==null)
        {
            if(cars.size()<capacity)
            {
                cars.put(id,car);

            }
            else{
               throw new ParkingLotException("停车场满了");
            }
        }

    }

    public boolean delete(String id) throws ParkingLotException {
        boolean result=false;
        if(id==null)
        {
            throw new ParkingLotException("该车牌号不存在");
        }
        else
        {
            if(cars.get(id)!=null)
            {
                 cars.remove(id);
                 result=true;
                 return result;

            }

        }
        throw  new ParkingLotException("不存在这辆车");

    }
}
