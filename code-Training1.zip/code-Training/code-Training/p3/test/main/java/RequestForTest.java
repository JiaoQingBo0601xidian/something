
public class RequestForTest implements CmdRequest{

}
