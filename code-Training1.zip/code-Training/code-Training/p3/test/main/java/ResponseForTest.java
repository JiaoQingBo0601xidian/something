import com.sun.org.apache.regexp.internal.RE;

public class ResponseForTest implements CmdResponse{
    private long code=-1;
    private boolean isCalled;

    @Override
    public void setResultCode(long ResultCode) {
        this.code= ResultCode;
    }

    @Override
    public void send() {
        this.isCalled=true;
    }

    public long getCode() {
        return code;
    }

    public boolean isCalled() {
        return isCalled;
    }
}
