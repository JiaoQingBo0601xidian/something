public interface CmdResponse {

    public void setResultCode(long ResultCode);

    public void send();


}
