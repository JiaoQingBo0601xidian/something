/**
 * Created by jqb on 2016/8/7.
 */
public class CmdRequestImpl implements CmdRequest{
}
