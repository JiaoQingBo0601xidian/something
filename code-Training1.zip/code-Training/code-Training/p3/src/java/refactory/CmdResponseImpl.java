/**
 * Created by jqb on 2016/8/7.
 */
public class CmdResponseImpl implements CmdResponse{
    private long resultCode=-1;
    private boolean isSent=false;


    @Override
    public void setResultCode(long ResultCode) {
        this.resultCode=ResultCode;
    }

    @Override
    public void send() {
        this.isSent=true;
    }

    public long getResultCode() {
        return this.resultCode;
    }

    public boolean isSent() {
        return this.isSent;
    }
}
