public class UnitTyper {
	private static final int OAM_INQ_MGWMRB_UNIT = 0;
	private static final int OAM_INQ_MGWVTC_UNIT = 1;
	private static final int OAM_INQ_MGWIWF_UNIT = 2;
	private static final int OAM_INQ_MGWVTV_UNIT = 3;
	private static final int OAM_INQ_MGWVTCL_UNIT = 4;
	private static final int OAM_INQ_MGWVMAS_UNIT = 5;

	private static final int UT_3G_ETCIWF = 0;
	private static final int UT_3G_ETC = 1;
	private static final int UT_3G_ETV = 2;
	private static final int UT_3G_ETC_2 = 3;
	private static final int UT_3G_IWF = 4;

	private static final long NO_ETC_UNIT_MGW = 0;
	private static final long NO_ETC_ETV_UNIT_MGW = 1;
	private static final long NO_IWF_UNIT_MGW = 2;
	private static final long NO_ETV_UNIT_MGW = 3;
	private static final long NO_ETC_2_UNIT_MGW = 4;



	public static boolean checkUnitType(  CmdRequest cCmdReq, CmdResponse cCmdRsp, int in_ucInqType, int out_wUnitType )
	{

		if (  OAM_INQ_MGWMRB_UNIT == in_ucInqType  )
		{
			if ( ( UT_3G_ETC != out_wUnitType ) && ( UT_3G_ETCIWF != out_wUnitType ) )
			{
				return processResponse(cCmdRsp, NO_ETC_UNIT_MGW);
			}
		}

		if (  OAM_INQ_MGWVTC_UNIT  == in_ucInqType )
		{
			if ( ( UT_3G_ETC != out_wUnitType ) && ( UT_3G_ETV != out_wUnitType ) && ( UT_3G_ETCIWF != out_wUnitType ) )
			{
				return processResponse(cCmdRsp, NO_ETC_ETV_UNIT_MGW);
			}
		}

		if ( ( OAM_INQ_MGWIWF_UNIT  == in_ucInqType ) || ( OAM_INQ_MGWVMAS_UNIT == in_ucInqType ) )
		{
			if ( ( UT_3G_IWF != out_wUnitType ) && ( UT_3G_ETCIWF != out_wUnitType ) )
			{
				return processResponse(cCmdRsp, NO_IWF_UNIT_MGW);
			}
		}
		if ( OAM_INQ_MGWVTV_UNIT  == in_ucInqType && UT_3G_ETV != out_wUnitType )
		{
			return processResponse(cCmdRsp, NO_ETV_UNIT_MGW);
		}
		if ( OAM_INQ_MGWVTCL_UNIT  == in_ucInqType && UT_3G_ETC_2 != out_wUnitType )
		{
			return processResponse(cCmdRsp, NO_ETC_2_UNIT_MGW);
		}
		return true;
	}

	private static boolean processResponse(CmdResponse cCmdRsp, long resultCode) {
		cCmdRsp.setResultCode(resultCode);
		cCmdRsp.send();
		return false;
	}
}