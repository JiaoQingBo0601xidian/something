public interface CmdRequest {

}
