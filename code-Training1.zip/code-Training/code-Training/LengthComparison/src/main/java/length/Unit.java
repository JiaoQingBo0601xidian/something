package length;

public class Unit
{
    private int count;
    private UnitCenter unit;

    public Unit(int count, UnitCenter unit)
    {
        this.count = count;
        this.unit = unit;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Unit unit = (Unit) o;
        return this.unit.getClass() == ((Unit) o).unit.getClass() && getUnitValue() == unit.getUnitValue();
    }
    public Unit add(Unit unit) {
        if (this.unit.getClass() != unit.unit.getClass()) {
            throw new TypeNotMatchException("参数类型不匹配");
        }
        int sum = getUnitValue() + unit.getUnitValue();
        return new Unit(sum, this.unit.getMinType());
    }
    public int getCount() {
        return count;
    }

    private int getUnitValue() {
        return getCount() * unit.getScale();
    }

    public String printUnit() {
        return getUnitValue() + unit.getMinType().toString().toUpperCase();
    }

    public String printWithMaxUnit() {
        StringBuffer stringBuffer = new StringBuffer();
        int remainder = getUnitValue();
        for (LengthCenter lengthScale : LengthCenter.values()) {
            int divisor = remainder / lengthScale.getScale();
            if (divisor > 0) {
                stringBuffer.append(divisor).append(lengthScale.toString()).append(" ");
                remainder %= lengthScale.getScale();
            }
        }
        return stringBuffer.toString().trim();
    }


    
    @Override
    public int hashCode()
    {
        int result = count;
        result = 31 * result + (unit != null ? unit.hashCode() : 0);
        return result;
    }
}
