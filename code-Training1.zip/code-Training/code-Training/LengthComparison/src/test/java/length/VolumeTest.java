package length;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static length.VolumeCenter.*;

public class VolumeTest
{
    @Test
    public void should_be_equals_when_compared_between_1_TBSP_and_3_TSP() throws Exception
    {
        assertEquals(new Unit(1, TBSP), new Unit(3, TSP));
    }

    @Test
    public void should_be_equal_when_compared_between_1_OZ_and_2_TBSP() throws Exception
    {
        assertEquals(new Unit(1, OZ), new Unit(2, TBSP));
    }

    @Test
    public void should_not_be_equal_when_compared_between_1_OZ_and_3_TBSP() throws Exception
    {
        assertFalse(new Unit(1, OZ).equals(new Unit(3, TBSP)));
    }
    @Test
    public void should_equals_between_12TSP_and_1OZ_plus_2TBSP() throws Exception {
        Assert.assertEquals(new Unit(12, VolumeCenter.TSP), new Unit(1, VolumeCenter.OZ).add(new Unit(2, VolumeCenter.TBSP)));
    }

    @Test
    public void should_not_equals_between_12TSP_and_1OZ_plus_3TBSP() throws Exception {
        Assert.assertNotEquals(new Unit(12, VolumeCenter.TSP), new Unit(1, VolumeCenter.OZ).add(new Unit(3, VolumeCenter.TBSP)));
    }

    @Test(expected = TypeNotMatchException.class)
    public void should_throwException_when_1Feet_plus_3TBSP() throws Exception {
        new Unit(1, LengthCenter.FEET).add(new Unit(3, VolumeCenter.TBSP));
    }
    @Test
    public void should_print_12TSP_when_input_2OZ() {
        String expected = "12TSP";
        assertEquals(expected, new Unit(2, VolumeCenter.OZ).printUnit());
    }

    @Test
    public void should_print_9TSP_when_input_3TBSP() {
        String expected = "9TSP";
        assertEquals(expected, new Unit(3, VolumeCenter.TBSP).printUnit());
    }

    @Test
    public void should_print_5TSP_when_input_5TSP() {
        String expected = "5TSP";
        assertEquals(expected, new Unit(5, VolumeCenter.TSP).printUnit());
    }
}
