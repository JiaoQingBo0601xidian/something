import org.junit.Assert;
import org.junit.Test;

/**
 * Created by 10198118 on 2016/4/23.
 */
public class LengthCalculatorTest {

    @Test
    public void 一Mile等于1760Yard() throws Exception
    {
        Feet feet=new Feet(1);
        Inch inch=new Inch(12);
        Assert.assertTrue(feet.lengthUnitCompare(inch));

    }
    @Test
    public void 一Yard等于3Feet() throws Exception
    {
        Yard yard=new Yard(1);
        Feet feet=new Feet(3);
        Assert.assertTrue(yard.lengthUnitCompare(feet));

    }
    @Test
    public void 一Mile等于5280Feet() throws Exception
    {
        Mile mile=new Mile(1);
        Feet feet=new Feet(5280);
        Assert.assertTrue(mile.lengthUnitCompare(feet));

    }
    @Test
    public void 一Feet等于12Inch() throws Exception{
        Feet feet=new Feet(1);
        Inch inch=new Inch(12);
        Assert.assertTrue(feet.lengthUnitCompare(inch));

    }
    @Test
    public void 一Yard等于36Inch() throws Exception{
        Yard yard=new Yard(1);
        Inch inch=new Inch(36);
        Assert.assertTrue(yard.lengthUnitCompare(inch));

    }
    @Test
    public void 一Mile等于63360Inch() throws Exception{
        Mile mile=new Mile(1);
        Inch inch=new Inch(63360);
        Assert.assertTrue(mile.lengthUnitCompare(inch));

    }



}
