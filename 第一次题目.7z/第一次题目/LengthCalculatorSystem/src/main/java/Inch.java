/**
 * Created by 10198118 on 2016/4/23.
 */
public class Inch extends  LengthUnit{
    private static final int INCH_BASE=63360;
    public int getBase()
    {
        return this.INCH_BASE;
    }
    public Inch(long count) {
        super(count);
    }
}
