/**
 * Created by 10198118 on 2016/4/23.
 */
public class Mile extends LengthUnit{
    public final static int MAIL_BASE=1;

    public int getBase()
    {
        return this.MAIL_BASE;

    }
    public Mile(long count)
    {
        super(count);
    }
}
