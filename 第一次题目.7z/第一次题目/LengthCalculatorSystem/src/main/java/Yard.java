/**
 * Created by 10198118 on 2016/4/23.
 */
public class Yard extends LengthUnit{
    private static final int YARD_BASE=1760;

    public int getBase()
    {
        return this.YARD_BASE;
    }


    public Yard(long count) {
        super(count);

    }


}
