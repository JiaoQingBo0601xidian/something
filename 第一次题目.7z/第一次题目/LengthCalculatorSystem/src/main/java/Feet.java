import sun.security.util.Length;

/**
 * Created by 10198118 on 2016/4/23.
 */
public class Feet extends LengthUnit{
    private static final int FEET_BASE=5280;

    public int getBase()
    {
        return this.FEET_BASE;
    }

    public Feet(long count) {
        super(count);
    }
}
