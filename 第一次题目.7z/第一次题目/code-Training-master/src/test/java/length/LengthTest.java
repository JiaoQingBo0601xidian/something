package length;

import org.junit.Test;

import static length.LengthCenter.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class LengthTest
{
    /*
       1Mile = 1760Yard

       �����������һ���µĵ�λ��Feet
       1Yard = 3Feet
       1Mile = 5280Feet

       ���������ټ���һ���µĵ�λ��Inch
       1Feet = 12Inch
       1Yard = 36Inch
       1Mile  = 63360Inch*/

    @Test
    public void should_return_equals_when_input_1Mile_and_1760Yard()
    {
        assertEquals(new Unit(1, MILE), new Unit(1760, YARD));
    }

    @Test
    public void should_false_when_input_1Mile_and_1761Yard()
    {
        assertFalse(new Unit(1, MILE).equals(new Unit(1761, YARD)));
    }

    @Test
    public void should_return_equals_when_input_1Yard_and_3Feet()
    {
        assertEquals(new Unit(1, YARD), new Unit(3, FEET));

    }

    @Test
    public void should_not_equal_when_input_1Feet_and_13Inch()
    {
        assertFalse(new Unit(1, FEET).equals(new Unit(13, INCH)));

    }

    @Test
    public void should_return_equals_when_input_1Yard_and_36Inch()
    {
        assertEquals(new Unit(1, YARD), new Unit(36, INCH));

    }

    @Test
    public void should_return_equals_when_input_1Mile_and_63360Inch()
    {
        assertEquals(new Unit(1, MILE), new Unit(63360, INCH));
    }
}
