package length;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static length.VolumeCenter.*;

public class VolumeTest
{
    @Test
    public void should_be_equals_when_compared_between_1_TBSP_and_3_TSP() throws Exception
    {
        assertEquals(new Unit(1, TBSP), new Unit(3, TSP));
    }

    @Test
    public void should_be_equal_when_compared_between_1_OZ_and_2_TBSP() throws Exception
    {
        assertEquals(new Unit(1, OZ), new Unit(2, TBSP));
    }

    @Test
    public void should_not_be_equal_when_compared_between_1_OZ_and_3_TBSP() throws Exception
    {
        assertFalse(new Unit(1, OZ).equals(new Unit(3, TBSP)));
    }
}
