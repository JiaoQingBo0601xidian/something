package length;

/**
 * Created by 00189971 on 2016/4/28.
 */
public enum VolumeCenter implements UnitCenter
{

    TSP(1), TBSP(1 * 3), OZ(1 * 2 * 3);

    private final int scale;

    VolumeCenter(int scale)
    {
        this.scale = scale;
    }

    @Override
    public int getScale()
    {
        return scale;
    }

}
