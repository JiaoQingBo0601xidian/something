package length;

public class Unit
{
    private int count;
    private UnitCenter unit;

    public Unit(int count, UnitCenter unit)
    {
        this.count = count;
        this.unit = unit;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }
        if (o == null || getClass() != o.getClass())
        {
            return false;
        }

        Unit targetVolume = (Unit) o;

        return this.count * this.unit.getScale() ==
                targetVolume.unit.getScale() * targetVolume.count;
    }

    @Override
    public int hashCode()
    {
        int result = count;
        result = 31 * result + (unit != null ? unit.hashCode() : 0);
        return result;
    }
}
