package length;


public interface UnitCenter
{
    public int getScale();
}
