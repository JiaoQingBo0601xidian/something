import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;


public class ParkingLotTest {
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Test
    public void should_can_park_car_when_parkinglot_is_not_full() throws ParkingLotException {
        List<ParkingLot> parkingLots=new ArrayList<ParkingLot>();
        ParkingLot parkLot=new ParkingLot(5);
        parkingLots.add(parkLot);
        Car car=new Car("10001");
        Admin admin=new Admin(parkingLots);
        admin.setParkingStrategy(new MaxRemainParkingStrategy());
        admin.park(car);
        assertEquals(admin.depart("10001"),true);

    }
    @Test
    public void should_can_not_park_car_when_parkinglot_is_full() throws ParkingLotException {
        expectedEx.expect(ParkingLotException.class);
        expectedEx.expectMessage("停车场满了");
        List<ParkingLot> parkingLots=new ArrayList<ParkingLot>();
        ParkingLot parkLot=new ParkingLot(1);
        parkingLots.add(parkLot);
        Car car=new Car("10001");
        Car car1=new Car("10002");
        Admin admin=new Admin(parkingLots);
        admin.setParkingStrategy(new MaxRemainParkingStrategy());
        admin.park(car);
        admin.park(car1);

    }

    @Test
    public void should_can_not_depart_car_when_a_car_is_not_park_in_the_parkinglot() throws ParkingLotException {
       expectedEx.expect(ParkingLotException.class);
       expectedEx.expectMessage("不存在这辆车");
        List<ParkingLot> parkingLots=new ArrayList<ParkingLot>();
        ParkingLot parkLot=new ParkingLot(5);
        parkingLots.add(parkLot);
        Admin admin=new Admin(parkingLots);
        admin.depart("10003");

    }


    @Test
    public void should_park_car_in_the_parkinglot_which_has_more_remain_when_a_car_is_park_in_the_parkinglot() throws ParkingLotException {

        List<ParkingLot> parkingLots=new ArrayList<ParkingLot>();
        ParkingLot parkLot1=new ParkingLot(1);
        ParkingLot parkLot2=new ParkingLot(2);
        ParkingLot parkLot3=new ParkingLot(3);
        ParkingLot parkLot4=new ParkingLot(4);
        parkingLots.add(parkLot1);
        parkingLots.add(parkLot2);
        parkingLots.add(parkLot3);
        parkingLots.add(parkLot4);
        Admin admin=new Admin(parkingLots);
        Car car=new Car("10001");
        admin.setParkingStrategy(new MaxRemainParkingStrategy());
        admin.park(car);

        assertEquals(parkLot1.getCars().size(),0);
        assertEquals(parkLot2.getCars().size(),0);
        assertEquals(parkLot3.getCars().size(),0);
        assertEquals(parkLot4.getCars().get(0),car);

    }



    @Test
    public void should_park_car_in_the_parkinglot_which_has_more_ratio_remain_when_a_car_is_park_in_the_parkinglot() throws ParkingLotException {

        List<ParkingLot> parkingLots=new ArrayList<ParkingLot>();
        ParkingLot parkLot1=new ParkingLot(4);
        ParkingLot parkLot2=new ParkingLot(4);
        ParkingLot parkLot3=new ParkingLot(4);
        ParkingLot parkLot4=new ParkingLot(4);
        parkingLots.add(parkLot1);
        parkingLots.add(parkLot2);
        parkingLots.add(parkLot3);
        parkingLots.add(parkLot4);
        Admin admin=new Admin(parkingLots);

        Car car1=new Car("10001");
        Car car2=new Car("10002");
        Car car3=new Car("10003");
        Car car4=new Car("10004");


        admin.setParkingStrategy(new MaxRatioRemainParkingStrategy());
        admin.park(car1);
        admin.park(car2);
        admin.park(car3);
        admin.park(car4);
        assertEquals(parkLot1.getCars().get(0),car1);
        assertEquals(parkLot2.getCars().get(0),car2);
        assertEquals(parkLot3.getCars().get(0),car3);
        assertEquals(parkLot4.getCars().get(0),car4);


    }





}
