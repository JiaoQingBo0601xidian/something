/**
 * Created by 10198118 on 2016/6/21.
 */
public class ParkingLotException extends Exception {
    public ParkingLotException(String msg) {
        super(msg);
    }
}
