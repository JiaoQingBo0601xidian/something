import java.util.List;

/**
 * Created by jqb on 2016/7/10.
 */
public interface ParkingStrategy {
    public void parkingCar(Car car,List<ParkingLot> parkingLots) throws ParkingLotException;
}
