package iterator3;

public class Car {
    private String carId;

    public String getCarId() {
        return carId;
    }



    public Car(String carId) {
        this.carId=carId;
    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public boolean equals(Object obj) {
        Car o=(Car)obj;
        return this.getCarId()==o.getCarId();

    }
}
