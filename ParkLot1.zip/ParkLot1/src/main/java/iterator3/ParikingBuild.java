package iterator3;

import java.util.List;


public class ParikingBuild {
    private List<ParkingLot> parkingLotList;
    private Admin admin;
}
