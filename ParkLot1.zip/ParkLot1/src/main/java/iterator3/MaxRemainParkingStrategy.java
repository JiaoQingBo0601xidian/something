package iterator3;

import java.util.List;


public class MaxRemainParkingStrategy implements ParkingStrategy {
    public void parkingCar(Car car, List<ParkingLot> parkingLots) throws ParkingLotException {
        ParkingLot beingChoosen = null;
        double max= 0;
        for (ParkingLot parkingLot : parkingLots)
        {
            double capacity = parkingLot.getCapacity();
            double used=parkingLot.getCars().size();
            double remain=capacity-used;
            if(max<remain)
            {
                max = remain;
                beingChoosen=parkingLot;
            }

        }

        if (max > 0) {
            beingChoosen.add(car.getCarId(), car);
            return;
        }


        throw new ParkingLotException("停车场满了");
    }
}
