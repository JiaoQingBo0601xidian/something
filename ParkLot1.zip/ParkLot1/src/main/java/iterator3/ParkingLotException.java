package iterator3;


public class ParkingLotException extends Exception {
    public ParkingLotException(String msg) {
        super(msg);
    }
}
