package iterator3;

import java.util.List;


public class Manager {
    private List<Admin> admins;

    private ParkingStrategy parkingStrategy;

    public void setParkingStrategy(ParkingStrategy parkingStrategy) {
        this.parkingStrategy = parkingStrategy;
    }

    public void park(Car car) throws ParkingLotException {
        parkingStrategy.parkingCar(car,admins);
    }

}
