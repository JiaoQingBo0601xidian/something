package iterator3;

import java.util.List;

public class Admin {
    private List<ParkingLot> parkingLots;
    private ParkingStrategy parkingStrategy;

    public void setParkingStrategy(ParkingStrategy parkingStrategy) {
        this.parkingStrategy = parkingStrategy;
    }

    public Admin(List<ParkingLot> parkLots) {
        this.parkingLots = parkLots;
    }

    public void park(Car car) throws ParkingLotException {
       parkingStrategy.parkingCar(car,parkingLots);
    }

    public boolean depart(String id) throws ParkingLotException {
        for (ParkingLot parkingLot : parkingLots) {
            if (parkingLot.delete(id) == true) {
                return true;
            }
        }
        throw new ParkingLotException("不存在这辆车");

    }

}
