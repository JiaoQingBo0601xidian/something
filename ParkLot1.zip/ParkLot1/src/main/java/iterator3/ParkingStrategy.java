package iterator3;

import java.util.List;

interface ParkingStrategy {
     void parkingCar(Car car, List<ParkingLot> parkingLots) throws ParkingLotException;
}
